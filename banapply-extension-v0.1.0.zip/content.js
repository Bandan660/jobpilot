"use strict";(()=>{function ie(e){if(!e)return null;let t=e.toUpperCase().replace(/[\s-]+/g,"_");return/FULL/.test(t)?"FULL_TIME":/PART/.test(t)?"PART_TIME":/CONTRACT|FREELANCE|C2H/.test(t)?"CONTRACTOR":/INTERN/.test(t)?"INTERN":/TEMP/.test(t)?"TEMPORARY":/VOLUNTEER/.test(t)?"VOLUNTEER":/PER_DIEM/.test(t)?"PER_DIEM":null}var nr=200*1024;var or=9*1024*1024*1024,W={jobUrl:2048,title:300,company:200,location:200,externalId:200,compRaw:500,adapterVersion:50};function Mt(e){let t=(n,o)=>{if(n===null)return null;let a=n.trim();return a?a.length<=o?a:`${a.slice(0,o-1)}\u2026`:null};return{...e,jobUrl:e.jobUrl.length<=W.jobUrl?e.jobUrl:to(e.jobUrl),title:t(e.title,W.title),company:t(e.company,W.company),location:t(e.location,W.location),externalId:t(e.externalId,W.externalId),compRaw:t(e.compRaw,W.compRaw),adapterVersion:e.adapterVersion.slice(0,W.adapterVersion)}}function to(e){try{return new URL(e).origin}catch{return e.slice(0,W.jobUrl)}}var rr=new RegExp("[\\u0300-\\u036f]","g");function It(e,t=new Date){if(!e)return"";let n=typeof e=="string"?new Date(e):e,o=typeof t=="string"?new Date(t):t;if(Number.isNaN(n.getTime())||Number.isNaN(o.getTime()))return"";let a=Math.floor((o.getTime()-n.getTime())/1e3);if(a<45)return"just now";let r=(m,f)=>`${m} ${f}${m===1?"":"s"} ago`,i=Math.floor(a/60);if(i<60)return r(Math.max(1,i),"minute");let s=Math.floor(i/60);if(s<24)return r(s,"hour");let l=Math.floor(s/24);if(l<7)return l===1?"yesterday":r(l,"day");let u=Math.floor(l/7);if(l<30)return r(u,"week");let d=Math.floor(l/30);return d<12?r(d,"month"):r(Math.floor(l/365),"year")}var Ht=["gender","ethnicity","veteranStatus","disabilityStatus"],no={secondaryScore:["IN"],higherSecondaryScore:["IN"],graduationScore:["IN"],lastWorkingDay:["IN"],gender:["US"],ethnicity:["US"],veteranStatus:["US"],disabilityStatus:["US"]},Rt={amountCents:null,currency:null,period:null};var sr={current:{...Rt},expected:{...Rt}};function qt(e){return e.toLowerCase().replace(/\s*\*\s*$/,"").replace(/[^a-z0-9\s]/g," ").replace(/\s+/g," ").trim().slice(0,120)}var _t={SECONDARY:1,HIGHER_SECONDARY:2,CERTIFICATION:3,DIPLOMA:4,BACHELORS:5,MASTERS:6,DOCTORATE:7};function Dt(e){return e.education.reduce((t,n)=>n.level?t?.level?_t[n.level]>_t[t.level]?n:t:n:t,null)}function nt(e,t){return e.education.find(n=>n.level===t)??null}function oo(e){let t=0;for(let n of e.experience){if(!n.startDate)continue;let o=new Date(`${n.startDate}-01`),a=n.current||!n.endDate?new Date:new Date(`${n.endDate}-01`);Number.isNaN(o.getTime())||Number.isNaN(a.getTime())||(t+=Math.max(0,(a.getFullYear()-o.getFullYear())*12+(a.getMonth()-o.getMonth())))}return t}function Ot(e,t=""){if(e.amountCents===null)return null;let n=e.amountCents/100;if(/\b(lpa|lakh|lakhs|lac|lacs)\b/i.test(t)){let o=n/1e5;return Number.isInteger(o)?String(o):o.toFixed(2).replace(/\.?0+$/,"")}return String(Math.round(n))}function Ft(e,t,n=""){let o=r=>r===null?null:r?"Yes":"No",a=no[t];if(a&&!a.some(r=>e.regions.includes(r)))return null;switch(t){case"fullName":{let r=[e.firstName,e.lastName].filter(Boolean);return r.length?r.join(" "):null}case"authorizedToWork":return o(e.authorizedToWork);case"requiresSponsorship":return o(e.requiresSponsorship);case"willingToRelocate":return o(e.willingToRelocate);case"preferredLocations":return e.preferredLocations.length?e.preferredLocations.join(", "):null;case"skills":return e.skills.length?e.skills.join(", "):null;case"languages":return e.languages.length?e.languages.join(", "):null;case"currentCompensation":return Ot(e.compensation.current,n);case"expectedCompensation":return Ot(e.compensation.expected,n);case"noticePeriod":{let r=e.availability.noticePeriodDays;return r===null?null:r===0?"Immediate":/\bmonths?\b/i.test(n)?String(Math.round(r/30)):/\bweeks?\b/i.test(n)?String(Math.round(r/7)):String(r)}case"lastWorkingDay":return e.availability.lastWorkingDay;case"earliestStartDate":return e.availability.earliestStartDate;case"totalExperience":{let r=oo(e);return r<=0?null:/\bmonths?\b/i.test(n)?String(r):String(Math.floor(r/12))}case"highestQualification":{let r=Dt(e);return r?.degree??r?.level??null}case"graduationYear":{let r=Dt(e);return r?.endDate?r.endDate.slice(0,4):null}case"secondaryScore":return nt(e,"SECONDARY")?.score??null;case"higherSecondaryScore":return nt(e,"HIGHER_SECONDARY")?.score??null;case"graduationScore":return nt(e,"BACHELORS")?.score??null;case"gender":return e.demographics.enabled?e.demographics.gender:null;case"ethnicity":return e.demographics.enabled?e.demographics.ethnicity:null;case"veteranStatus":return e.demographics.enabled?e.demographics.veteranStatus:null;case"disabilityStatus":return e.demographics.enabled?e.demographics.disabilityStatus:null;default:return e[t]??null}}var $t={JavaScript:["javascript","ecmascript","es6"],TypeScript:["typescript"],Python:["python"],Java:["java"],"C#":["c#","csharp","c sharp"],"C++":["c++","cpp"],Go:["golang","go lang"],Rust:["rust","rustlang"],Ruby:["ruby"],PHP:["php"],Swift:["swiftui","swift ui","swift programming","swift developer"],Kotlin:["kotlin"],Scala:["scala"],R:["r programming","r language"],SQL:["sql"],Bash:["bash","shell scripting"],"Objective-C":["objective-c","objective c"],Dart:["dart"],Elixir:["elixir"],React:["react","react.js","reactjs"],"Next.js":["next.js","nextjs"],Vue:["vue","vue.js","vuejs"],Nuxt:["nuxt","nuxt.js"],Angular:["angular","angularjs"],Svelte:["svelte","sveltekit"],"React Native":["react native"],Flutter:["flutter"],Redux:["redux"],HTML:["html","html5"],CSS:["css","css3"],Sass:["sass","scss"],"Tailwind CSS":["tailwind","tailwindcss","tailwind css"],Bootstrap:["bootstrap"],Webpack:["webpack"],Vite:["vite"],jQuery:["jquery"],Accessibility:["accessibility","a11y","wcag"],"Responsive design":["responsive design","responsive web"],"Node.js":["node.js","nodejs","node js"],Express:["express","express.js","expressjs"],NestJS:["nestjs","nest.js"],Django:["django"],Flask:["flask"],FastAPI:["fastapi"],"Spring Boot":["spring boot","springboot"],Laravel:["laravel"],Rails:["ruby on rails","rails"],".NET":[".net","dotnet","asp.net"],GraphQL:["graphql"],REST:["rest api","rest apis","restful"],gRPC:["grpc"],Microservices:["microservice","microservices"],WebSockets:["websocket","websockets","socket.io"],PostgreSQL:["postgresql","postgres"],MySQL:["mysql"],MongoDB:["mongodb","mongo"],Redis:["redis"],Elasticsearch:["elasticsearch","elastic search"],DynamoDB:["dynamodb"],Cassandra:["cassandra"],SQLite:["sqlite"],Prisma:["prisma"],Kafka:["kafka"],RabbitMQ:["rabbitmq"],Spark:["apache spark","pyspark"],Airflow:["airflow"],ETL:["etl","elt"],"Data modelling":["data modeling","data modelling"],Pandas:["pandas"],NumPy:["numpy"],AWS:["aws","amazon web services"],Azure:["azure"],GCP:["gcp","google cloud"],Docker:["docker"],Kubernetes:["kubernetes","k8s"],Terraform:["terraform"],Ansible:["ansible"],"CI/CD":["ci/cd","continuous integration","continuous delivery"],Jenkins:["jenkins"],"GitHub Actions":["github actions"],Serverless:["serverless","aws lambda","cloud functions"],Cloudflare:["cloudflare"],Nginx:["nginx"],Linux:["linux","unix"],Observability:["prometheus","grafana","datadog","observability"],Git:["git","version control"],Agile:["agile","scrum","kanban"],Testing:["unit testing","unit tests","jest","pytest","vitest","test coverage"],"E2E testing":["cypress","playwright","selenium","end-to-end testing"],TDD:["tdd","test driven development","test-driven development"],"Code review":["code review","code reviews"],"System design":["system design","distributed systems","scalability"],Security:["owasp","penetration testing","application security","appsec"],"Performance tuning":["performance optimization","performance optimisation","performance tuning"],"Machine learning":["machine learning","ml models"],"Deep learning":["deep learning","neural network","neural networks"],TensorFlow:["tensorflow"],PyTorch:["pytorch"],LLMs:["llm","llms","large language model","openai api","prompt engineering"],NLP:["nlp","natural language processing"],"Computer vision":["computer vision","opencv"],Figma:["figma"],"UI/UX":["ui/ux","user experience","ux design"],SEO:["seo","search engine optimization","search engine optimisation"],Analytics:["google analytics","mixpanel","amplitude"]};function ao(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function ro(e){return new RegExp(`(?<![a-z0-9])${ao(e)}(?![a-z0-9])`,"i")}var io=Object.entries($t).map(([e,t])=>({canonical:e,patterns:t.filter((n,o,a)=>a.indexOf(n)===o).map(ro)}));function Ae(e){if(!e)return[];let t=[];for(let{canonical:n,patterns:o}of io)o.some(a=>a.test(e))&&t.push(n);return t}var so=/\b(nice[\s-]*to[\s-]*haves?|good[\s-]*to[\s-]*haves?|preferred|bonus|desirable|advantageous|pluses|optional)\b/i,lo=/\b(requirements?|required|responsibilities|qualifications|must[\s-]*haves?|what you.{0,3}ll do|what you.{0,3}ll bring|about you|who you are|your role|the role|key skills|essential)\b/i,co=/\b(is a plus|are a plus|a strong plus|nice to have|good to have|bonus points|would be a bonus|but not required)\b/i,uo=80;function po(e){return e.length>uo?!1:e.endsWith(":")||e.split(/\s+/).length<=5}function mo(e){let t=[],n=[],o=!1;for(let a of e.split(`
`)){let r=a.trim();if(r){if(po(r)){if(so.test(r)){o=!0,n.push(r);continue}if(lo.test(r)){o=!1,t.push(r);continue}}if(!o&&co.test(r)){n.push(r);continue}(o?n:t).push(r)}}return{required:t.join(`
`),optional:n.join(`
`)}}function fo(e){let n=[...e.matchAll(/(\d{1,2})\s*\+?\s*(?:-\s*\d{1,2}\s*)?years?/gi)].map(o=>Number.parseInt(o[1],10)).filter(o=>Number.isFinite(o)&&o>0&&o<=30);return n.length?Math.min(...n):null}function Jt(e,t){let n=mo(e),o=Ae(n.required),a=n.optional;o.length===0&&(o=Ae(e),a="");let r=new Set(o),i=Ae(a).filter(c=>!r.has(c)),s=[...t.skills??[],...(t.experience??[]).flatMap(c=>[c.title??"",c.description??""])].filter(Boolean).join(`
`),l=new Set(Ae(s)),u=o.filter(c=>l.has(c)),d=o.filter(c=>!l.has(c)),m=i.filter(c=>l.has(c)),f=i.filter(c=>!l.has(c));return{bonus:m,preferred:f,score:o.length===0?0:Math.round(u.length/o.length*100),matched:u,missing:d,yearsWanted:fo(e)}}var cr=Object.keys($t).length;function F(e){return e.replace(/\s+/g," ").trim()}function y(e,t,n={}){let o=n.maxLength??300;for(let a of t){let r;try{r=e.querySelectorAll(a)}catch{continue}for(let i of r){let s=F(i.textContent??"");if(s&&s.length<=o)return s}}return null}function ot(e,t,n){for(let o of t){let a=e.querySelector(o)?.getAttribute(n),r=a?F(a):"";if(r)return r}return null}function se(e,t){for(let n of t){let o=n.replace(/"/g,'\\"'),a=ot(e,[`meta[property="${o}"]`,`meta[name="${o}"]`],"content");if(a)return a}return null}function be(e,t){let n=t.map(a=>a.toLowerCase()),o=e.querySelectorAll('dt, th, label, .label, [class*="label" i]');for(let a of o){let r=F(a.textContent??"").toLowerCase().replace(/[:*]\s*$/,"");if(!n.some(s=>r===s||r.startsWith(s)))continue;let i=F(a.nextElementSibling?.textContent??"");if(i&&i.length<=200)return i}return null}function le(e){return e&&/\b(remote|work from home|wfh|telecommute|anywhere)\b/i.test(e)?!0:null}function E(e){return e.pathname.split("/").filter(Boolean)}function Te(e,t){let n=e.hostname.toLowerCase();return t.some(o=>o.startsWith(".")?n.endsWith(o):n===o)}var bo=/^(www|jobs?|careers?|apply|apply-|recruiting|hire|hiring|talent)$/i;function Ce(e){let n=(e.hostname.toLowerCase().split(".")[0]??"").replace(/^(careers?|jobs?|apply|recruiting)[-_]/,"");return!n||bo.test(n)?null:$(n)}function $(e){return e.replace(/[-_]+/g," ").replace(/\b\w/g,t=>t.toUpperCase()).trim()}var Ut={ats:"GREENHOUSE",version:"greenhouse@1",matches(e){return e.hostname==="boards.greenhouse.io"||e.hostname==="job-boards.greenhouse.io"},isJobPage(e){let t=E(e);return t.includes("jobs")&&t.length>=3?!0:e.pathname.includes("/embed/job_app")&&e.searchParams.has("token")},extract(e,t){let n=E(t),o=n[0]&&n[0]!=="embed"?n[0]:null,a=n.indexOf("jobs"),r=a>=0&&n[a+1]?n[a+1]:t.searchParams.get("token"),i={title:y(e,["h1.app-title",".job__title h1",".job__title","h1"]),company:y(e,[".company-name",".job__company",'[data-testid="company-name"]'])??(o?$(o):null),location:y(e,[".location",".job__location",'[class*="location"]']),externalId:r};return i.company&&(i.company=i.company.replace(/^at\s+/i,"").trim()),i},descriptionSelectors:["#content",".job__description",'[class*="job__description"]'],confirmationSelectors:["#application_confirmation",".application-confirmation",'[data-testid="application-confirmation"]']};var Bt={ats:"LEVER",version:"lever@1",matches(e){return e.hostname==="jobs.lever.co"},isJobPage(e){return E(e).length>=2},extract(e,t){let n=E(t),o=n[0]??null,a=n[1]??null,r=e.querySelector(".main-header-logo img, .posting-logo img")?.alt?.trim(),i={title:y(e,[".posting-headline h2",'[data-qa="posting-name"]',"h2"]),company:r||(o?$(o):null),location:y(e,[".posting-categories .location",".posting-category.location",'[class*="location"]']),compRaw:y(e,[".posting-categories .commitment + .salary",'[class*="salary"]']),externalId:a};return i.location&&(i.location=i.location.replace(/^[\s•/|-]+/,"").trim()),i},descriptionSelectors:[".section-wrapper.page-full-width",'[data-qa="job-description"]',".content"],confirmationSelectors:[".application-confirmation",".postings-confirmation","#confirmation"]};var zt={ats:"ASHBY",version:"ashby@1",matches(e){return e.hostname==="jobs.ashbyhq.com"},isJobPage(e){let t=E(e);return t.length<2?!1:/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(t[1])},extract(e,t){let n=E(t),o=n[0]??null;return{title:y(e,["h1",'[class*="jobPostingHeader"] h1']),company:y(e,['[class*="companyName"]','header a[href="/"]'])??(o?$(o):null),location:y(e,['[class*="jobPostingHeaderSubtitle"]','[class*="location"]']),compRaw:y(e,['[class*="compensation"]','[class*="salary"]']),externalId:n[1]??null}},confirmationSelectors:['[class*="applicationConfirmation"]','[class*="submitted"]']};var go=[".jobs-easy-apply-modal","[data-test-modal]","dialog[open]",'[aria-modal="true"]','div[role="dialog"]'];function _(e){let t=e.getBoundingClientRect();return t.width>0&&t.height>0}function ge(e){return e.querySelector("input, select, textarea")!==null}function ce(e=()=>!0){for(let t of go)for(let n of document.querySelectorAll(t))if(_(n)&&e(n))return n;return null}function rt(){return ce(ge)}function at(e){let t=e.searchParams.get("currentJobId");return t||(e.pathname.match(/\/jobs\/view\/([^/?#]+)/)?.[1]?.match(/(\d+)$/)?.[1]??null)}var Gt={ats:"LINKEDIN",version:"linkedin@1",matches(e){return e.hostname==="linkedin.com"||e.hostname.endsWith(".linkedin.com")},isJobPage(e){return!e.pathname.startsWith("/jobs")&&!e.pathname.startsWith("/my-items")?!1:at(e)!==null},expectedExternalId(e){return at(e)},renderedExternalId(e){let t=e.querySelector(".jobs-search__job-details")??e.querySelector(".job-view-layout")??e.querySelector("main");if(!t)return null;let n=t.querySelector("[data-job-id], [data-occludable-job-id]"),o=n?.getAttribute("data-job-id")??n?.getAttribute("data-occludable-job-id")??null;return o&&/^\d+$/.test(o)?o:t.querySelector('a[href*="/jobs/view/"]')?.getAttribute("href")?.match(/\/jobs\/view\/(\d+)/)?.[1]??null},extract(e,t){let n=e.querySelector(".jobs-search__job-details")??e.querySelector(".jobs-details__main-content")??e.querySelector(".job-view-layout")??e.querySelector("main")??e,o=y(n,[".job-details-jobs-unified-top-card__job-title h1",".jobs-unified-top-card__job-title",".job-details-jobs-unified-top-card__job-title",".topcard__title","h1"]),a=y(n,[".job-details-jobs-unified-top-card__company-name a",".job-details-jobs-unified-top-card__company-name",".jobs-unified-top-card__company-name",".topcard__org-name-link",'[data-tracking-control-name="public_jobs_topcard-org-name"]','[class*="top-card"] a[href*="/company/"]','a[href*="/company/"]']),r=y(n,[".job-details-jobs-unified-top-card__primary-description-container",".job-details-jobs-unified-top-card__bullet",".jobs-unified-top-card__bullet",".topcard__flavor--bullet"]),i=r?r.split("\xB7")[0]?.trim()??null:null,s=null,l=null;if(!o||!a){let f=(e.querySelector('meta[property="og:title"]')?.getAttribute("content")?.trim()||e.title||"").replace(/\s*\|\s*LinkedIn\s*$/i,"").trim().replace(/^\(\d+\)\s*/,""),c=f.match(/^(.+?)\s+hiring\s+(.+?)(?:\s+in\s+.+)?$/i);c?(l=c[1]?.trim()??null,s=c[2]?.trim()??null):f&&!/^jobs?$/i.test(f)&&(s=f)}return{title:o??s,company:(a??l)?.replace(/\s+/g," ").trim()??null,location:i,externalId:at(t)}},descriptionSelectors:[".jobs-description__content",".jobs-box__html-content",'[class*="jobs-description"]',"#job-details",".show-more-less-html__markup",".description__text"],confirmationSelectors:[".jobs-easy-apply-content__success",".post-apply-timeline",'[data-test-modal] h2[id*="post-apply"]'],confirmationScope(){return ce()??document.querySelector(".post-apply-timeline")}};function Yt(e){let t=E(e).filter(a=>a!=="apply"&&!a.startsWith("apply")).pop();if(!t)return null;let n=t.lastIndexOf("_");return n<0?null:decodeURIComponent(t.slice(n+1))||null}function Le(e,t){return e&&F(e.replace(t,""))||null}var Wt={ats:"WORKDAY",version:"workday@1",matches(e){return Te(e,[".myworkdayjobs.com"])},isJobPage(e){let t=E(e);return t.includes("job")||t.includes("details")},extract(e,t){let n=Le(y(e,['[data-automation-id="locations"] dd','[data-automation-id="locations"]','[data-automation-id="location"]','[data-automation-id="jobPostingLocation"]'],{maxLength:160}),/^locations?\s*/i),o=Le(y(e,['[data-automation-id="time"] dd','[data-automation-id="time"]'],{maxLength:80}),/^time\s*type\s*/i),a=Le(y(e,['[data-automation-id="requisitionId"]'],{maxLength:80}),/^(job\s*)?(requisition\s*)?id\s*/i),r=ot(e,['[data-automation-id="companyLogo"] img','[data-automation-id="companyLogo"]',"header img[alt]"],"alt"),i=(r?F(r.replace(/\s*(logo|careers?)\s*$/i,"")):null)||Ce(t);return{title:y(e,['[data-automation-id="jobPostingHeader"]','[data-automation-id="jobTitle"]',"h1","h2"],{maxLength:200}),company:i,location:n,remote:le(n),employmentType:ie(o),externalId:a??Yt(t)}},expectedExternalId(e){return Yt(e)},renderedExternalId(e){return Le(y(e,['[data-automation-id="requisitionId"]'],{maxLength:80}),/^(job\s*)?(requisition\s*)?id\s*/i)},descriptionSelectors:['[data-automation-id="jobPostingDescription"]','[data-automation-id="job-posting-details"]'],confirmationSelectors:['[data-automation-id="applicationSubmitted"]','[data-automation-id="successBanner"]','[data-automation-id="confirmationPage"]']};function it(e,t){let n=F(e).replace(/^job\s+application\s+for\s+/i,"").replace(/^apply\s+(?:for|to)\s+/i,""),o=/\s+[|–—•-]\s+/,a=n.split(o);if(a.length>1){let r=a[a.length-1].toLowerCase();(/^(careers?|jobs?|job\s+board|hiring|apply|vacancies|work\s+with\s+us)$/.test(r)||t!==null&&r.includes(t.toLowerCase()))&&(n=a.slice(0,-1).join(" - "))}if(t){let r=t.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");n=n.replace(new RegExp(`\\s+(?:at|@)\\s+${r}\\s*$`,"i"),"")}return F(n)}var ho=/^(careers?|jobs?|home|apply|job\s+details?|vacancies|open\s+roles?)$/i;function st(e,t){return!(!e||ho.test(e)||t&&e.toLowerCase()===t.toLowerCase())}function C(e){return{ats:e.ats??"GENERIC",version:e.version,matches(t){return Te(t,e.hosts)},isJobPage(t){return e.isJobPage(t)},extract(t,n){let o=y(t,e.company??[],{maxLength:120})??e.companyFallback?.(n,t)??se(t,["og:site_name"])??Ce(n),a=y(t,[...e.title??[],"h1"],{maxLength:200})??se(t,["og:title","twitter:title"])??(t.title?t.title:null),r=y(t,e.location??[],{maxLength:160})??(e.labels?.location?be(t,e.labels.location):null),i=y(t,e.comp??[],{maxLength:160})??(e.labels?.comp?be(t,e.labels.comp):null),s=a?it(a,o):"";return{title:st(s,o)?s:null,company:o,location:r,remote:le(r),compRaw:i,externalId:e.externalId?.(n,t)??null,...e.extra?.(t,n)}},confirmationSelectors:e.confirmationSelectors??[],descriptionSelectors:e.descriptionSelectors??[]}}function w(e,t){let n=E(e),o=n.indexOf(t);return o>=0?n[o+1]??null:null}function J(e){if(!e)return null;let t=/^(\d{3,})(?:[-_]|$)/.exec(e);if(t)return t[1];let n=/[-_](\d{4,})$/.exec(e);return n?n[1]:e||null}function lt(e){return t=>{let n=E(t)[e];return n?$(decodeURIComponent(n)):null}}var yo=C({ats:"SMARTRECRUITERS",version:"smartrecruiters@1",hosts:[".smartrecruiters.com"],isJobPage:e=>{let t=E(e);return t.length>=2&&/^\d{5,}/.test(t[1])},title:['h1[itemprop="title"]','[data-test="job-title"]',"spl-job-title",".job-title"],company:['[itemprop="hiringOrganization"]','[data-test="company-name"]',".company-name"],location:['[itemprop="jobLocation"]',"spl-job-location","#st-locations",".job-location"],comp:['[itemprop="baseSalary"]','[data-test="job-compensation"]'],companyFallback:lt(0),externalId:e=>J(E(e)[1]),confirmationSelectors:['[data-test="thank-you"]',".thank-you",".application-submitted"]}),xo=C({version:"workable@1",hosts:[".workable.com"],isJobPage:e=>w(e,"j")!==null,title:['[data-ui="job-title"]','[data-ui="overview-title"]'],company:['[data-ui="company-name"]','[data-ui="overview-company"]'],location:['[data-ui="job-location"]','[data-ui="overview-location"]','[data-ui="location"]'],comp:['[data-ui="job-salary"]','[data-ui="overview-salary"]'],companyFallback:lt(0),externalId:e=>w(e,"j"),confirmationSelectors:['[data-ui="application-success"]','[data-ui="thank-you"]']}),wo=C({ats:"ICIMS",version:"icims@1",hosts:[".icims.com"],isJobPage:e=>/^\d+$/.test(w(e,"jobs")??"")||e.searchParams.has("jobId"),title:["h1.iCIMS_Header",".iCIMS_Header",'[itemprop="title"]',".iCIMS_JobHeaderTitle"],location:['.iCIMS_JobHeaderField [itemprop="jobLocation"]','[itemprop="jobLocation"]'],labels:{location:["job locations","job location","locations","location"],comp:["compensation","salary","pay range"]},externalId:e=>w(e,"jobs")??e.searchParams.get("jobId"),confirmationSelectors:[".iCIMS_ThankYou","#icims_content_confirmation"]}),vo=C({version:"taleo@1",hosts:[".taleo.net"],isJobPage:e=>e.pathname.includes("jobdetail")||e.searchParams.has("job"),title:['[id*="reqTitleLinkAction"]','[id*="requisitionDescriptionInterface.reqTitle"]',".titlepage"],labels:{location:["primary location","job location","work locations","location"],comp:["salary","compensation","pay"]},externalId:e=>e.searchParams.get("job"),confirmationSelectors:['[id*="confirmation"]',".confirmationtext"]}),Eo=C({version:"successfactors@1",hosts:[".successfactors.com",".successfactors.eu"],isJobPage:e=>e.searchParams.has("career_job_req_id")||e.searchParams.has("jobId")||e.pathname.toLowerCase().includes("jobreq"),title:['[data-careersite-propertyid="title"]',".jobTitle","#content h1"],company:['[data-careersite-propertyid="companyname"]'],location:['[data-careersite-propertyid="location"]','[data-careersite-propertyid="city"]'],labels:{location:["location","work location"]},companyFallback:e=>e.searchParams.get("company"),externalId:e=>e.searchParams.get("career_job_req_id")??e.searchParams.get("jobId"),confirmationSelectors:[".jobApplicationConfirmation",'[id*="confirmation"]']}),So=C({version:"teamtailor@1",hosts:[".teamtailor.com"],isJobPage:e=>w(e,"jobs")!==null,title:["h1",'[class*="job-title"]'],company:['[class*="company-name"]','header a[rel="home"]'],location:['[class*="location"]','[data-controller*="location"]'],externalId:e=>J(w(e,"jobs")),confirmationSelectors:['[class*="application-success"]','[class*="thank"]']}),ko=C({version:"recruitee@1",hosts:[".recruitee.com"],isJobPage:e=>w(e,"o")!==null,title:["h1",'[class*="job-title"]',".job-title"],company:['[class*="company-name"]',".header__company"],location:['[class*="location"]',".job-location"],externalId:e=>w(e,"o"),confirmationSelectors:['[class*="thank-you"]',".c-application__success"]}),Ao=C({version:"personio@1",hosts:[".jobs.personio.de",".jobs.personio.com"],isJobPage:e=>w(e,"job")!==null,title:["h1",'[class*="jobTitle"]',".job-title"],location:['[class*="jobLocation"]','[class*="location"]'],externalId:e=>w(e,"job"),confirmationSelectors:['[class*="application-success"]','[class*="thank"]']}),To=C({version:"bamboohr@1",hosts:[".bamboohr.com"],isJobPage:e=>/^\d+$/.test(w(e,"careers")??""),title:["h1",'[class*="jobTitle"]','[data-testid*="title"]'],company:['[class*="companyName"]','[data-testid*="company"]'],location:['[class*="jobLocation"]','[class*="location"]'],externalId:e=>w(e,"careers"),confirmationSelectors:['[class*="applicationSuccess"]','[class*="thank"]']}),Co=C({version:"jobvite@1",hosts:[".jobvite.com"],isJobPage:e=>w(e,"job")!==null,title:[".jv-header",".jv-job-detail-title","h1"],location:[".jv-job-detail-meta",'[class*="jv-job-detail-location"]'],companyFallback:e=>{let t=E(e),n=t.indexOf("job"),o=n>0?t[n-1]:null;return o?$(decodeURIComponent(o)):null},externalId:e=>w(e,"job"),confirmationSelectors:[".jv-confirmation",'[class*="jv-thank"]']}),Lo=C({version:"zohorecruit@1",hosts:[".zohorecruit.com",".zohorecruit.in",".zohorecruit.eu"],isJobPage:e=>/^\d+$/.test(w(e,"Careers")??""),title:["h1",".job-title",'[class*="jobTitle"]'],location:['[class*="location"]'],labels:{location:["city","location","work location"]},externalId:e=>w(e,"Careers"),confirmationSelectors:['[class*="thank"]','[class*="success"]']}),No=C({version:"darwinbox@1",hosts:[".darwinbox.in",".darwinbox.com"],isJobPage:e=>{let t=E(e),n=t.indexOf("careers");return n>=0&&t.length>n+1},title:["h1",".job-title",'[class*="jobTitle"]','[class*="job_title"]'],location:['[class*="location"]'],labels:{location:["location","job location"]},externalId:e=>E(e).pop()??null,confirmationSelectors:['[class*="thank"]','[class*="success"]']}),jo=C({version:"keka@1",hosts:[".keka.com"],isJobPage:e=>w(e,"jobdetails")!==null,title:["h1",".job-title",'[class*="jobTitle"]'],location:['[class*="location"]'],labels:{location:["location","job location"],comp:["salary","ctc"]},externalId:e=>w(e,"jobdetails"),confirmationSelectors:['[class*="thank"]','[class*="success"]']}),Kt=[yo,xo,wo,vo,Eo,So,ko,Ao,To,Co,Lo,No,jo];var Po=C({version:"naukri@1",hosts:["www.naukri.com",".naukri.com"],isJobPage:e=>/^job-listings-/.test(E(e)[0]??"")||e.pathname.includes("job-listings")||e.pathname.includes("job-overview"),title:['[class*="jd-header-title"]','[class*="title"] h1',"h1"],company:['[class*="jd-header-comp-name"] a','[class*="jd-header-comp-name"]','[class*="comp-name"]','[class*="companyName"]'],location:['[class*="jhc__location"]','[class*="location"] a','[class*="loc"] span','[class*="location"]'],comp:['[class*="salary"]','[class*="jhc__salary"]'],externalId:e=>J(E(e)[0])}),Mo=C({version:"indeed@1",hosts:[".indeed.com",".indeed.co.in","indeed.com","indeed.co.in","smartapply.indeed.com"],isJobPage:e=>e.pathname.includes("/viewjob")||e.pathname.includes("/rc/clk")||e.pathname.includes("/jobs")||e.pathname.includes("/indeedapply")||e.searchParams.has("vjk")||e.searchParams.has("jk"),title:['[data-testid="simulated-title"]',".jobsearch-JobInfoHeader-title","h1.jobsearch-JobInfoHeader-title",'[class*="JobInfoHeader-title"]','[data-testid="job-title"]',".ia-JobTitle","h1"],company:['[data-testid="inlineHeader-companyName"] a','[data-testid="inlineHeader-companyName"]',".jobsearch-InlineCompanyRating-companyHeader",'[data-testid="company-name"]',".ia-CompanyName",'[class*="companyName"]'],location:['[data-testid="inlineHeader-companyLocation"]',".jobsearch-JobInfoHeader-subtitle",'[class*="companyLocation"]'],comp:["#salaryInfoAndJobType",'[data-testid="jobMetaData"]','[class*="salary"]'],descriptionSelectors:["#jobDescriptionText",'[data-testid="jobDescriptionText"]',".jobsearch-JobComponent-description",".jobsearch-jobDescriptionText",'[class*="JobDescriptionText"]'],confirmationSelectors:['[data-testid="post-apply-container"]','[data-testid="ia-PostApplyContainer"]',".ia-PostApplyContainer",'[class*="PostApply"]','[class*="post-apply"]','a[href*="MyJobs"]'],externalId:e=>e.searchParams.get("vjk")??e.searchParams.get("jk")??J(E(e).pop())}),Io=C({version:"foundit@1",hosts:["www.foundit.in",".foundit.in",".foundit.com"],isJobPage:e=>e.pathname.includes("/seeker/job-details")||e.pathname.includes("/job/")||w(e,"job")!==null,title:["h1.job-title",'[class*="jobTitle"]','[class*="jd-header-title"]',"h1"],company:['[class*="company-name"]','[class*="companyName"]',".companyName"],location:['[class*="location"]','[class*="job-location"]'],comp:['[class*="salary"]','[class*="package"]'],externalId:e=>J(E(e).pop())}),Ro=C({version:"glassdoor@1",hosts:[".glassdoor.com",".glassdoor.co.in"],isJobPage:e=>e.pathname.includes("/Job/")||e.pathname.includes("/job-listing/")||e.searchParams.has("jl"),title:['[data-test="job-title"]',".JobDetails_jobTitle__","h1"],company:['[data-test="employer-name"]',".EmployerProfile_employerName__",'[class*="Employer"]'],location:['[data-test="location"]',".JobDetails_location__",'[class*="Location"]'],externalId:e=>e.searchParams.get("jl")??J(E(e).pop())}),_o=C({version:"instahyre@1",hosts:["www.instahyre.com",".instahyre.com"],isJobPage:e=>w(e,"job")!==null,title:["h1",'[class*="job-title"]',".job-title"],company:['[class*="company-name"]',".company-name"],location:['[class*="location"]'],externalId:e=>w(e,"job")}),Do=C({version:"cutshort@1",hosts:["cutshort.io",".cutshort.io"],isJobPage:e=>w(e,"job")!==null,title:["h1",'[class*="job-title"]'],company:['[class*="company-name"]','[class*="companyName"]'],location:['[class*="location"]'],externalId:e=>J(w(e,"job"))}),Oo=C({version:"hirist@1",hosts:["www.hirist.tech",".hirist.tech",".hirist.com"],isJobPage:e=>w(e,"j")!==null,title:["h1",'[class*="job-title"]','[class*="jobTitle"]'],company:['[class*="company-name"]','[class*="companyName"]'],location:['[class*="location"]'],externalId:e=>J(w(e,"j"))}),Ho=C({version:"seek@1",hosts:["www.seek.com.au",".seek.com.au",".seek.co.nz"],isJobPage:e=>/^\d+$/.test(w(e,"job")??""),title:['[data-automation="job-detail-title"]',"h1"],company:['[data-automation="advertiser-name"]','[data-automation="job-header-company-review-title"]'],location:['[data-automation="job-detail-location"]'],comp:['[data-automation="job-detail-salary"]'],externalId:e=>w(e,"job"),extra:e=>({employmentType:ie(y(e,['[data-automation="job-detail-work-type"]'],{maxLength:60}))})}),Vt=[Po,Mo,Io,Ro,_o,Do,Oo,Ho];function Xt(e){return Array.isArray(e)?e:e==null?[]:[e]}function qo(e){if(typeof e!="object"||e===null)return[];let t=e["@type"];return Xt(t).filter(n=>typeof n=="string")}function ct(e,t=0){if(t>6||typeof e!="object"||e===null)return null;if(Array.isArray(e)){for(let o of e){let a=ct(o,t+1);if(a)return a}return null}if(qo(e).includes("JobPosting"))return e;let n=e["@graph"];return n?ct(n,t+1):null}function j(e){if(typeof e=="string"){let t=e.trim();return t||null}return typeof e=="number"?String(e):null}function Fo(e){let t=Xt(e.jobLocation),n=[];for(let o of t){if(typeof o!="object"||o===null)continue;let a=o.address;if(typeof a!="object"||a===null)continue;let r=a,i=j(r.addressLocality),s=j(r.addressRegion),l=j(r.addressCountry)??j(r.addressCountry?.name),u=[i,s,l].filter(Boolean).join(", ");u&&n.push(u)}return n.length>0?n.join(" | "):null}function $o(e){let t=e.baseSalary;if(typeof t!="object"||t===null)return null;let n=t,o=j(n.currency)??"",a=n.value;if(typeof a=="object"&&a!==null){let i=a,s=j(i.minValue),l=j(i.maxValue),u=j(i.value),d=j(i.unitText)??"";if(s&&l)return`${o} ${s} - ${l} ${d}`.trim();if(u)return`${o} ${u} ${d}`.trim()}let r=j(a);return r?`${o} ${r}`.trim():null}function Jo(e){let t=j(e.jobLocationType);return t&&t.toUpperCase().includes("TELECOMMUTE")?!0:null}function Uo(e){let t=e.identifier;return typeof t=="string"?t:typeof t=="object"&&t!==null?j(t.value):null}function dt(e){let t=e.querySelectorAll('script[type="application/ld+json"]');for(let n of t){let o;try{o=JSON.parse(n.textContent??"")}catch{continue}let a=ct(o);if(a)return a}return null}function Qt(e){return dt(e)!==null}function Zt(e){let t=dt(e),n=t?j(t.description):null;if(!n)return null;let o=e.createElement("div");o.innerHTML=n;for(let r of o.querySelectorAll("li"))r.textContent=`- ${r.textContent?.trim()??""}`;for(let r of o.querySelectorAll("p, div, br, li, h1, h2, h3, h4"))r.after(e.createTextNode(`
`));return(o.textContent??"").replace(/[ \t]+/g," ").replace(/\n{3,}/g,`

`).trim()||null}function en(e){let t=dt(e);if(!t)return null;let n=t.hiringOrganization,o=j(typeof n=="object"&&n!==null?n.name:n);return{title:j(t.title),company:o,location:Fo(t),remote:Jo(t),employmentType:ie(Array.isArray(t.employmentType)?String(t.employmentType[0]):t.employmentType),externalId:Uo(t),compRaw:$o(t)}}var tn={ats:"GENERIC",version:"generic@1",matches(){return!0},isJobPage(){return Qt(document)},extract(e){let t=se(e,["og:site_name"]),n=y(e,["h1"],{maxLength:200})??se(e,["og:title"]),o=be(e,["location","job location","locations"]),a=n?it(n,t):"";return{title:st(a,t)?a:null,company:t,location:o,remote:le(o)}},confirmationSelectors:[]};var Bo=[Ut,Bt,zt,Gt,Wt,...Kt,...Vt,tn];function he(e){return Bo.find(t=>t.matches(e))??null}var nn=[/\bpassword\b/,/\bpasscode\b/,/\bpin\b/,/\bsecurity.?question\b/,/mother'?s.?maiden/,/\bcredit.?card\b/,/\bcard.?number\b/,/\bcvv\b/,/\bcvc\b/,/\bsecurity.?code\b/,/\bbank\b/,/\brouting\b/,/\biban\b/,/\bswift\b/,/\bbic\b/,/\bsort.?code\b/,/\bifsc\b/,/\bupi\b/,/\bssn\b/,/social.?security/,/\bsin\b/,/social.?insurance/,/national.?insurance/,/\bni\s*(number|no)\b/,/\bnino\b/,/\bppsn\b/,/\baadhaar\b/,/\baadhar\b/,/\buidai\b/,/\bpan\b/,/\bpan.?card\b/,/\buan\b/,/\bpf.?(number|no|account)\b/,/\bnif\b/,/\bnie\b/,/\bbsn\b/,/codice.?fiscale/,/steuer.?id/,/\binsz\b/,/\btfn\b/,/\bcpf\b/,/\bcnpj\b/,/\brfc\b/,/\bcurp\b/,/\btax.?id\b/,/\bpassport\b/,/\bnational.?id/,/\bidentity.?(card|number)\b/,/driv(ing|er'?s).?licen[cs]e/,/\bvisa.?number\b/,/date.?of.?birth/,/\bdob\b/],on=new Set(["password","hidden","file","submit","button","image","reset"]),an=[{field:"firstName",autocomplete:["given-name"],patterns:[/first.?name/,/\bfname\b/,/given.?name/,/\bforename\b/],weight:20},{field:"lastName",autocomplete:["family-name"],patterns:[/last.?name/,/\blname\b/,/family.?name/,/\bsurname\b/],weight:20},{field:"preferredName",patterns:[/preferred.?name/,/nick.?name/,/goes.?by/],weight:25},{field:"fullName",autocomplete:["name"],patterns:[/full.?name/,/your.?name/,/^name$/,/\bname\b/],negative:[/first/,/last/,/given/,/family/,/surname/,/preferred/,/nick/,/middle/,/company/,/employer/,/school/,/university/,/college/,/reference/,/user.?name/,/file.?name/],weight:5},{field:"email",autocomplete:["email"],patterns:[/\bemail\b/,/e-?mail/],negative:[/confirm/,/verify/,/reference/],inputTypes:["email","text"],weight:15},{field:"phone",autocomplete:["tel","tel-national"],patterns:[/\bphone\b/,/\bmobile\b/,/\bcell\b/,/telephone/,/contact.?number/],negative:[/country.?code/,/extension/,/reference/],inputTypes:["tel","text"],weight:15},{field:"phone",patterns:[/phone.?country.?code/,/country.?code.*phone/,/dial.?code/,/country.?dial/],weight:20},{field:"addressLine1",autocomplete:["address-line1","street-address"],patterns:[/street.?address/,/address.?line.?1/,/^address$/],negative:[/email/,/line.?2/,/city/,/state/,/zip/,/postal/,/country/]},{field:"city",autocomplete:["address-level2"],patterns:[/\bcity\b/,/\btown\b/,/locality/],negative:[/state/,/country/],weight:10},{field:"state",autocomplete:["address-level1"],patterns:[/\bstate\b/,/province/,/\bregion\b/,/county/],negative:[/united.?states/,/statement/]},{field:"postalCode",autocomplete:["postal-code"],patterns:[/postal.?code/,/\bzip\b/,/post.?code/,/\bpincode\b/]},{field:"country",autocomplete:["country","country-name"],patterns:[/\bcountry\b/],negative:[/country.?code/]},{field:"linkedinUrl",patterns:[/linked.?in/],weight:25},{field:"githubUrl",patterns:[/git.?hub/,/\bgit\b/],weight:25},{field:"portfolioUrl",patterns:[/portfolio/,/personal.?(web)?site/,/\bwebsite\b/,/\bblog\b/],negative:[/company.?website/,/linked/,/github/],weight:12},{field:"otherUrl",patterns:[/other.?(url|link|website)/,/additional.?(url|link)/,/\btwitter\b/,/\bx\.com\b/],weight:8},{field:"currentCompany",patterns:[/current.?(company|employer)/,/^company$/,/\bemployer\b/,/present.?company/],negative:[/why/,/about/,/size/,/reference/],weight:10},{field:"currentTitle",patterns:[/current.?(title|role|position)/,/job.?title/,/^title$/,/occupation/],negative:[/why/,/desired/,/reference/],weight:10},{field:"authorizedToWork",patterns:[/legally.?authorized/,/authorized.?to.?work/,/eligible.?to.?work/,/right.?to.?work/,/work.?authorization/],weight:30},{field:"requiresSponsorship",patterns:[/sponsor/,/visa.?support/,/require.?sponsorship/,/immigration.?status/],weight:30},{field:"willingToRelocate",patterns:[/relocat/,/willing.?to.?move/],weight:30},{field:"expectedCompensation",patterns:[/expected.?(ctc|salary|compensation|package|pay)/,/desired.?(salary|compensation|pay|ctc)/,/salary.?expectation/,/compensation.?expectation/,/salary.?required/],negative:[/current/,/present/,/existing/],weight:30},{field:"currentCompensation",patterns:[/current.?(ctc|salary|compensation|package|pay)/,/present.?(ctc|salary|compensation)/,/existing.?(ctc|salary)/,/\bctc\b/],negative:[/expected/,/desired/,/required/],weight:28},{field:"noticePeriod",patterns:[/notice.?period/,/\bnotice\b/,/how.?soon.?can.?you.?(join|start)/],negative:[/last.?working/,/notice.?board/],weight:26},{field:"lastWorkingDay",patterns:[/last.?working.?(day|date)/,/\blwd\b/,/last.?date.?of.?employment/],weight:30},{field:"earliestStartDate",patterns:[/earliest.?(start|joining|available)/,/available.?(to.?)?start/,/joining.?date/,/start.?date/,/availability/],negative:[/notice/,/previous/,/employment.?start/],weight:18},{field:"totalExperience",patterns:[/total.?(work.?|professional.?)?experience/,/years.?of.?experience/,/\byoe\b/,/experience.?in.?years/,/relevant.?experience/],negative:[/describe/,/tell.?us/],weight:24},{field:"skills",patterns:[/skills?/,/technical.?skills/,/key.?skills/,/technologies/],negative:[/soft.?skill.?example/,/describe/],weight:20},{field:"languages",patterns:[/languages?.?(known|spoken)/,/^languages?$/,/languages/],negative:[/programming/],weight:22},{field:"preferredLocations",patterns:[/preferred.?(location|city|work.?location)/,/desired.?location/,/location.?preference/],weight:26},{field:"highestQualification",patterns:[/highest.?(qualification|education|degree)/,/education.?level/,/qualification\b/],negative:[/percentage|marks|score|year/],weight:22},{field:"graduationYear",patterns:[/(passing|passout|pass.?out|graduation|completion).?year/,/year.?of.?(passing|graduation|completion)/,/\bbatch\b/],weight:26},{field:"secondaryScore",patterns:[/\b(10th|tenth|sslc|matriculation|class.?x)\b/,/secondary.?(school.?)?(percentage|marks)/],negative:[/12th|twelfth/],weight:28},{field:"higherSecondaryScore",patterns:[/\b(12th|twelfth|hsc|intermediate|class.?xii)\b/,/higher.?secondary/],weight:28},{field:"graduationScore",patterns:[/(graduation|degree|bachelor|\bug\b).?(percentage|marks|cgpa|gpa|score|aggregate)/,/(cgpa|gpa)\b/],negative:[/10th|12th|tenth|twelfth|sslc|hsc/],weight:24},{field:"referralSource",patterns:[/how.?did.?you.?hear/,/referral.?source/,/where.?did.?you.?find/,/how.?you.?found/],weight:25},{field:"gender",patterns:[/\bgender\b/,/\bsex\b/],negative:[/gender.?identity.?statement/],weight:20},{field:"ethnicity",patterns:[/ethnic/,/\brace\b/,/racial/,/hispanic/],weight:20},{field:"veteranStatus",patterns:[/veteran/,/military/,/protected.?veteran/],weight:20},{field:"disabilityStatus",patterns:[/disabilit/,/\bdisabled\b/],weight:20}];var zo=40;function ye(e){return e?.textContent?.replace(/\s+/g," ").trim()??""}function Go(e){let t=e.id;if(t){let u=typeof CSS<"u"&&CSS.escape?CSS.escape(t):t,d=document.querySelector(`label[for="${u}"]`);if(d)return ye(d)}let n=e.closest("label");if(n)return ye(n);let o=e.getAttribute("aria-labelledby");if(o){let u=o.split(/\s+/).map(d=>ye(document.getElementById(d))).filter(Boolean);if(u.length)return u.join(" ")}let a=e.getAttribute("aria-label");if(a)return a.trim();let i=e.closest('fieldset, [role="radiogroup"], [role="group"], [class*="form-element"], [class*="form-component"]')?.querySelector('legend, [class*="form-element__label"], [class*="form-component__label"], [data-test-form-element-label]');if(i)return ye(i);let l=e.closest("div, section, li, td")?.querySelector("label, legend, h1, h2, h3, h4, p, span");return l&&!l.contains(e)?ye(l):""}function Yo(e,t){return[e.getAttribute("name")??"",e.id,e.getAttribute("placeholder")??"",e.getAttribute("aria-label")??"",e.getAttribute("data-qa")??"",e.getAttribute("data-testid")??"",t].join(" ").toLowerCase().replace(/([a-z])([A-Z])/g,"$1 $2").replace(/[_\-.[\]]+/g," ").replace(/\s+/g," ").trim()}function Wo(e,t){let n=(e.getAttribute("type")??"").toLowerCase();return on.has(n)||e.getAttribute("autocomplete")==="off"&&n==="password"?!0:nn.some(o=>o.test(t))}function rn(e){let t=Go(e),n=Yo(e,t);if(Wo(e,n))return{control:e,field:null,score:0,label:t};let o=(e.getAttribute("autocomplete")??"").toLowerCase().trim(),a=(e.getAttribute("type")??"text").toLowerCase(),r=null;for(let i of an){if(i.negative?.some(l=>l.test(n))||i.inputTypes&&e instanceof HTMLInputElement&&!i.inputTypes.includes(a))continue;let s=0;o&&i.autocomplete?.includes(o)?s=100:i.patterns.some(l=>l.test(n))&&(s=60),s!==0&&(s+=i.weight??0,(!r||s>r.score)&&(r={field:i.field,score:s}))}return!r||r.score<zo?{control:e,field:null,score:r?.score??0,label:t}:{control:e,field:r.field,score:r.score,label:t}}function ut(e){if(e.closest('header, nav, [role="search"], [class*="search" i], [id*="search" i], [class*="header" i], [id*="header" i], [class*="nav" i], [id*="nav" i], [class*="JobAlert" i]')&&!e.closest('dialog, [role="dialog"], [class*="modal" i], [class*="indeed-apply" i], [class*="smartapply" i]'))return!0;let n=(e.name||"").toLowerCase(),o=(e.id||"").toLowerCase(),a=("placeholder"in e&&e.placeholder||"").toLowerCase(),r=(e.getAttribute("aria-label")||"").toLowerCase(),i=/^(q|l|query|keywords?|location|where|what|search|job-search|text-input-what|text-input-where)$/i;return!!((i.test(n)||i.test(o)||/job title|keywords|city, state|where|what/i.test(a)||/job title|keywords|location|where|what/i.test(r))&&!e.closest('dialog, [role="dialog"], [class*="modal" i], [class*="indeed-apply" i], [class*="smartapply" i]'))}function xe(e=document){let t=e.querySelectorAll("input, select, textarea"),n=[];for(let o of t)o.disabled||"readOnly"in o&&o.readOnly||ut(o)||!o.offsetParent&&o.type!=="radio"&&o.type!=="checkbox"||n.push(rn(o));return n}function cn(e){let t=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:e instanceof HTMLSelectElement?HTMLSelectElement.prototype:HTMLInputElement.prototype,n=Object.getOwnPropertyDescriptor(t,"value");return n?.set?n.set.bind(e):null}function pt(e){e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0}))}function dn(e,t){let n=cn(e);return n?n(t):e.value=t,pt(e),e.value===t}function B(e){return e.toLowerCase().replace(/[^a-z0-9]+/g," ").trim()}function Ko(e,t){let n=B(t);if(!n)return null;let o=[...e.options].filter(i=>i.value!==""),a=o.find(i=>B(i.text)===n||B(i.value)===n);if(a)return a;let r=o.find(i=>B(i.text).startsWith(n));if(r)return r;if(n.length>=4){let i=o.find(s=>B(s.text).includes(n));if(i)return i}return null}function Vo(e,t){let n=Ko(e,t);return n?dn(e,n.value):!1}function Xo(e,t){let n=e.name;if(!n)return!1;let o=typeof CSS<"u"&&CSS.escape?CSS.escape(n):n,a=document.querySelectorAll(`input[type="radio"][name="${o}"]`),r=B(t);for(let i of a){let s=i.closest("label")?.textContent??document.querySelector(`label[for="${i.id}"]`)?.textContent??i.value,l=B(s??"");if(l===r||l.startsWith(r))return i.checked||(i.checked=!0,pt(i),i.dispatchEvent(new PointerEvent("pointerdown",{bubbles:!0,cancelable:!0,pointerId:1,isPrimary:!0})),i.dispatchEvent(new MouseEvent("mousedown",{bubbles:!0})),i.dispatchEvent(new PointerEvent("pointerup",{bubbles:!0,cancelable:!0,pointerId:1,isPrimary:!0})),i.dispatchEvent(new MouseEvent("mouseup",{bubbles:!0})),i.dispatchEvent(new MouseEvent("click",{bubbles:!0}))),!0}return!1}function Qo(e,t){let n=t.trim().toLowerCase(),o=/^(yes|true|1|consent|i consent|agree|accept|read and understand|i agree)$/i.test(n)||n.includes("consent")||n.includes("agree")||n.includes("accept");if(e.checked===o)return!0;e.checked=o,pt(e),e.dispatchEvent(new PointerEvent("pointerdown",{bubbles:!0,cancelable:!0,pointerId:1,isPrimary:!0})),e.dispatchEvent(new MouseEvent("mousedown",{bubbles:!0})),e.dispatchEvent(new PointerEvent("pointerup",{bubbles:!0,cancelable:!0,pointerId:1,isPrimary:!0})),e.dispatchEvent(new MouseEvent("mouseup",{bubbles:!0})),e.dispatchEvent(new MouseEvent("click",{bubbles:!0}));let a=e.closest("label")??document.querySelector(`label[for="${e.id}"]`);if(a&&a instanceof HTMLElement)try{a.click()}catch{}return!0}function mt(e){if(!(e instanceof HTMLInputElement))return!1;let t=e.getAttribute("aria-autocomplete");return e.getAttribute("role")==="combobox"||t==="list"||t==="both"}function Ne(e,t,n=!1){if(!t)return"no-match";if(e instanceof HTMLInputElement){let o=e.type.toLowerCase();if(o==="radio")return Xo(e,t)?"filled":"no-match";if(o==="checkbox")return Qo(e,t)?"filled":"no-match"}return!n&&e.value.trim()!==""?"skipped-filled":e instanceof HTMLSelectElement?Vo(e,t)?"filled":"no-match":mt(e)?"no-match":dn(e,t)?"filled":"failed"}var sn=e=>new Promise(t=>setTimeout(t,e)),Zo=2500;function ea(e){let t=e.getAttribute("aria-controls")??e.getAttribute("aria-owns");if(t){let o=e.ownerDocument.getElementById(t);if(o)return o}return e.closest('dialog, [role="dialog"], [aria-modal="true"]')?.querySelector('[role="listbox"]')??e.ownerDocument.querySelector('[role="listbox"]')}function ln(e,t){let n=B(t);if(!n)return null;let o=a=>B(a.innerText||a.textContent||"");return e.find(a=>o(a)===n)??e.find(a=>o(a).startsWith(n))??e.find(a=>n.startsWith(o(a))&&o(a).length>=4)??(n.length>=4?e.find(a=>o(a).includes(n)):void 0)??null}async function un(e,t){e.focus();let n=cn(e);n?n(t):e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new KeyboardEvent("keydown",{bubbles:!0,key:"ArrowDown"})),e.dispatchEvent(new KeyboardEvent("keyup",{bubbles:!0,key:"ArrowDown"})),e.dispatchEvent(new Event("change",{bubbles:!0}));let o=Date.now()+Zo,a=null;for(;Date.now()<o&&!a;){await sn(120);let i=[...ea(e)?.querySelectorAll('[role="option"], [data-value], [data-option], li[id*="option"], li[class*="option"], li[class*="suggestion"], li[class*="item"], .ac-menu-item, .suggestion-item, .dropdown-item')??[]].filter(s=>(s.innerText||s.textContent||"").trim()!=="");if(i.length>0&&(a=ln(i,t)),!a&&i.length===0){let s=e.ownerDocument.querySelector('[role="listbox"], .suggestions, .autocomplete-dropdown, .dropdown-menu');if(s){let l=[...s.querySelectorAll('[role="option"], li, [data-value], [class*="option"], [class*="item"]')].filter(u=>(u.innerText||u.textContent||"").trim()!=="");l.length>0&&(a=ln(l,t))}}}return!(!a||(a.dispatchEvent(new MouseEvent("mousedown",{bubbles:!0})),a.dispatchEvent(new MouseEvent("mouseup",{bubbles:!0})),a.click(),await sn(400),e.value.trim()===""))}function we(e){let t=e,n=t.style.boxShadow;t.style.transition="box-shadow 200ms ease",t.style.boxShadow="0 0 0 2px rgba(255, 176, 32, 0.85)",setTimeout(()=>{t.style.boxShadow=n},1600)}var pn=12;function ta(e,t){if(!t||t.length<pn)return null;let n=qt(t);return e.savedAnswers.find(a=>a.key===n)?.answer??null}function je(e,t={}){let{overwrite:n=!1,showHighlights:o=!0,root:a}=t,r=xe(a),i={filled:0,skipped:0,unmatched:0,unanswered:[],byField:{}};for(let s of r){let l=ft(e,s);if(l===null){s.control instanceof HTMLTextAreaElement&&s.label.length>=pn&&i.unanswered.push({label:s.label}),i.unmatched+=1;continue}let u=Ne(s.control,l,n);s.field&&(i.byField[s.field]=u),u==="filled"?(i.filled+=1,o&&we(s.control)):u==="skipped-filled"?i.skipped+=1:i.unmatched+=1}return i}async function Pe(e,t={}){let{overwrite:n=!1,showHighlights:o=!0,root:a}=t,r={filled:0,failed:[]};for(let i of xe(a)){let s=i.control;if(!mt(s)||!(s instanceof HTMLInputElement)||s.disabled||s.readOnly||!n&&s.value.trim()!=="")continue;let l=ft(e,i);l!==null&&(await un(s,l)?(r.filled+=1,o&&we(s)):r.failed.push({label:i.label}))}return r}function ft(e,t){if(t.field){if(Ht.includes(t.field)&&!e.demographics.enabled)return null;let n=Ft(e,t.field,t.label);if(n)return n}return ta(e,t.label)}function bt(e,t){let o=xe(t).filter(r=>r.control.type!=="hidden"&&!r.control.disabled);return{fillable:o.filter(r=>ft(e,r)!==null).length,total:o.length}}var na=[".artdeco-inline-feedback--error",".field-error",".form-error",".error-message",'[data-automation-id="errorMessage"]','[role="alert"]','[aria-live="assertive"]',"[aria-errormessage]",'[class*="error" i]','[class*="invalid" i]'];function oa(e){return e.filter(t=>!e.some(n=>n!==t&&t.contains(n)))}var mn=200,aa=8;function ra(e){return[...e.querySelectorAll("input, select, textarea")].filter(t=>{let n=t.tagName?.toLowerCase();if(n!=="input"&&n!=="select"&&n!=="textarea"||t.disabled)return!1;let o=t.type?.toLowerCase();if(o==="hidden"||o==="submit"||o==="button"||o==="image"||o==="reset"||ut(t))return!1;let a=(t.id||"").toLowerCase(),r=(t.name||"").toLowerCase(),i=(t.getAttribute("aria-label")||"").toLowerCase(),s=(t.className||"").toString().toLowerCase();if(/save-icon|savejob|bookmark|share|search|jobalert|alert-body|report|icon-/i.test(a)||/save-icon|savejob|bookmark|share|search|jobalert|alert-body|report|icon-/i.test(r)||/save-icon|savejob|save job|bookmark|share/i.test(i)||/save-icon|savejob|bookmark/i.test(s))return!1;if(o==="radio"||t.required||t.getAttribute("aria-required")==="true")return!0;let l=t.closest(fn);if(l){let u=(l.id||"").toLowerCase(),d=(l.className||"").toString().toLowerCase();return/save-icon|savejob|bookmark|share|search|header/i.test(u)||/save-icon|savejob|bookmark|share/i.test(d)?!1:l.getAttribute("aria-required")==="true"||l.hasAttribute("required")===!0||l.getAttribute("data-required")==="true"}return!1})}var fn=["fieldset",'[role="radiogroup"]','[role="group"]',"[data-test-form-element]","[data-test-single-typeahead-entity-form-component]","[data-automation-id]",".fb-dash-form-element",'[class*="form-element"]','[class*="form-component"]','[class*="form-group"]',".field",".form-group"].join(", ");function ia(e,t){let n=e.type?.toLowerCase();if(n==="file")return(e.files?.length??0)===0;if(n==="radio"||n==="checkbox"){let o=e;if(o.name)return![...t.querySelectorAll(`input[name="${CSS.escape(o.name)}"]`)].some(r=>r.checked);if(n==="radio"){let r=[...o.closest('fieldset, [role="radiogroup"], [role="group"]')?.querySelectorAll('input[type="radio"]')??[]];if(r.length>1)return!r.some(i=>i.checked)}return!o.checked}return!String(e.value??"").trim()}function z(e,t){let n=e.type?.toLowerCase(),o=n==="radio"||n==="checkbox",a=e.closest(fn),r=[()=>la(e),()=>sa(e,t)],i=[()=>a?.querySelector("legend")?.textContent,()=>a?.querySelector('[class*="form-element__label"], [class*="form-component__label"], [data-test-form-element-label], .fb-dash-form-element__label, .label, legend')?.textContent],s=o?[...i,...r]:[...r,...i];s.push(()=>e.getAttribute("aria-label"),()=>e.getAttribute("placeholder"),()=>{let l=e.getAttribute("name");return!l||/^(r\d+|input\d*|field\d*|_.*|\d+)$/i.test(l.trim())?null:l});for(let l of s){let u=gt(l()??"");if(u&&!/^radio-group-/i.test(u)&&!/save-icon|savejob|bookmark|share-icon|close-icon|report/i.test(u))return u}return"A required question"}function sa(e,t){let n=e.getAttribute("id");if(n){let o=t.querySelector?.(`label[for="${CSS.escape(n)}"]`);if(o?.textContent)return o.textContent}return e.closest("label")?.textContent??null}function la(e){let t=e.getAttribute("aria-labelledby");if(!t)return null;let n=e.ownerDocument;return t.split(/\s+/).map(a=>n.getElementById(a)?.textContent??"").join(" ").trim()||null}function gt(e){return e.replace(/\s+/g," ").replace(/\s*\*\s*$/,"").trim().slice(0,120)}function ca(e,t){if(e.id){let o=typeof CSS<"u"&&CSS.escape?CSS.escape(e.id):e.id,a=t.querySelector(`[aria-describedby~="${o}"], [aria-errormessage~="${o}"]`);if(a)return z(a,t)}let n=e.parentElement;for(let o=0;n&&o<4;o+=1,n=n.parentElement){let a=n.querySelectorAll("input, select, textarea");if(a.length===1)return z(a[0],t)}return""}function ht(e=document){let t=new Set,n=[],o=[];for(let r of ra(e)){let i=r.type;if(i==="hidden"||r.disabled||!(i==="file"||i==="radio"||i==="checkbox")&&!_(r)||!ia(r,e))continue;let l=z(r,e);!l||t.has(l)||(t.add(l),n.push({label:l,kind:"empty"}))}for(let r of e.querySelectorAll("input, select, textarea")){if(r.type==="hidden"||r.disabled)continue;let i=r.getAttribute("aria-invalid")==="true",s=r.validity,l=!!s&&!s.valid&&!s.valueMissing;if(!i&&!l)continue;let u=(r.getAttribute("aria-describedby")??"").split(/\s+/).map(f=>gt(r.ownerDocument.getElementById(f)?.textContent??"")).find(f=>f.length>0&&f.length<=mn),d=z(r,e),m=d&&u?`${d} \u2014 ${u}`:u||d;!m||t.has(m)||(u&&t.add(u),t.add(m),o.push({label:m,kind:"invalid"}))}let a=oa(na.flatMap(r=>[...e.querySelectorAll(r)]));for(let r of a){if(!_(r))continue;let i=gt(r.textContent??"");if(!i||i.length>mn||t.has(i))continue;let s=ca(r,e),l=s?`${s} \u2014 ${i}`:i;t.has(l)||(t.add(i),t.add(l),o.push({label:l,kind:"invalid"}))}return[...n,...o].slice(0,aa)}var da=/\b(resume|résumé|resumé|cv|curriculum\s*vitae)\b/i,bn=/\b(cover\s*letter|portfolio|transcript|certificate|photo|photograph|passport|visa|id\s*proof|payslip|reference\s*letter|writing\s*sample)\b/i;function gn(e){return[e.labels?.[0]?.textContent??e.closest("label")?.textContent??e.closest("[data-test-form-element], [data-automation-id], .field, .form-group, fieldset")?.querySelector("label, legend")?.textContent??"",e.getAttribute("name")??"",e.getAttribute("id")??"",e.getAttribute("aria-label")??"",e.getAttribute("placeholder")??"",e.getAttribute("data-qa")??"",e.getAttribute("data-ui")??""].join(" ").replace(/\s+/g," ").trim()}function ua(e){return e.disabled?!1:e.isConnected&&!!(e.offsetParent??e.getClientRects().length)}function yt(e=document){let t=[...e.querySelectorAll('input[type="file"]')].filter(r=>ua(r)||r.closest("form")!==null);if(t.length===0)return null;let n=t.map(r=>({input:r,text:gn(r)})),o=n.find(({text:r})=>da.test(r)&&!bn.test(r));if(o)return o.input;let a=n.filter(({text:r})=>!bn.test(r));return a.length===1?a[0].input:null}function pa(e){let t=atob(e),n=new ArrayBuffer(t.length),o=new Uint8Array(n);for(let a=0;a<t.length;a+=1)o[a]=t.charCodeAt(a);return n}function hn(e,t={}){let{scope:n=document,overwrite:o=!1}=t,a=yt(n);if(!a)return{status:"no-field"};let r=gn(a).slice(0,80)||"the resume field";if(!o&&(a.files?.length??0)>0)return{status:"already-attached",label:r};try{let i=new File([pa(e.data)],e.fileName,{type:e.contentType,lastModified:Date.now()});if(!ma(a,i))return{status:"failed",reason:`This form does not accept ${i.name.split(".").pop()??"that"} files here.`};let s=new DataTransfer;return s.items.add(i),a.files=s.files,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})),a.dispatchEvent(new DragEvent("drop",{bubbles:!0,cancelable:!0,dataTransfer:s})),(a.files?.length??0)===0?{status:"failed",reason:"The form rejected the file."}:{status:"attached",fileName:e.fileName,label:r}}catch(i){return{status:"failed",reason:i instanceof Error?i.message:"Could not attach the file."}}}function ma(e,t){let n=e.getAttribute("accept")?.trim();if(!n)return!0;let o=`.${t.name.split(".").pop()?.toLowerCase()??""}`;return n.split(",").some(a=>{let r=a.trim().toLowerCase();return r?r==="*/*"?!0:r.startsWith(".")?r===o:r.endsWith("/*")?t.type.startsWith(r.slice(0,-1)):r===t.type.toLowerCase():!1})}async function O(e){try{return chrome.runtime?.id?await chrome.runtime.sendMessage(e):{ok:!1,error:"BanApply was reloaded \u2014 refresh this page to reconnect."}}catch(t){let n=t instanceof Error?t.message:String(t);return n.includes("Extension context invalidated")?{ok:!1,error:"BanApply was reloaded \u2014 refresh this page to reconnect."}:{ok:!1,error:n}}}var fa=12,ba=250,de=500,ga=10*6e4,yn=3,ha=12e3,xn=3,ya=12,oe=e=>new Promise(t=>setTimeout(t,e));function H(...e){console.info("[jobpilot] apply:",...e)}async function xa(e,t){let n=Date.now()+t;for(;Date.now()<n;){let o=e();if(o)return o;await oe(120)}return null}function K(e,t){let n=[...e.querySelectorAll('button, input[type="submit"], [role="button"]')].filter(o=>!o.disabled&&_(o));for(let o of t){let a=n.find(i=>o.test(i.getAttribute("aria-label")??""));if(a)return a;let r=n.find(i=>o.test((i.textContent?.trim()||i.value)??""));if(r)return r}return null}function Ie(e){e.focus(),e.dispatchEvent(new PointerEvent("pointerdown",{bubbles:!0,cancelable:!0,pointerId:1,isPrimary:!0})),e.dispatchEvent(new MouseEvent("mousedown",{bubbles:!0,cancelable:!0,detail:1,view:window})),e.dispatchEvent(new PointerEvent("pointerup",{bubbles:!0,cancelable:!0,pointerId:1,isPrimary:!0})),e.dispatchEvent(new MouseEvent("mouseup",{bubbles:!0,cancelable:!0,detail:1,view:window})),e.click()}function wa(e){return[...e.querySelectorAll("textarea")].filter(t=>!t.disabled&&!t.readOnly&&_(t)).filter(t=>t.value.trim()==="").map(t=>({control:t,label:z(t,e)})).filter(({label:t})=>t.length>=ya)}async function Re({profile:e,flow:t,onProgress:n,isCancelled:o,draftAnswers:a=!1,job:r,autoSubmit:i=!1,snapshotAnswers:s}){let l=b=>(H(t.name,b.status,`step ${b.step}`,b.message),n(b),b),u=t.scope();if(!u&&t.open&&(l({status:"opening",step:0,message:"Opening the application\u2026"}),await t.open()&&(u=await xa(()=>t.scope(),8e3))),!u)return l({status:"error",step:0,message:"No application form on this page. Open the apply page first."});let d=0,m=!1,f=0,c=0,v="",S=0,x=!1,A=0,k="",L=!1,N="",P=Date.now(),Y=()=>{P=Date.now()},q=()=>l({status:"submitted",step:c,filled:d,message:`Sent \u2014 ${d} field${d===1?"":"s"} filled${m?", resume attached":""}.`});for(;Date.now()-P<ga;){if(o())return l({status:"cancelled",step:c,message:"Stopped."});let b=t.scope();if(!b)return x?q():l({status:"error",step:c,message:"The application form went away."});if(wn(b)!==v){if(c+=1,S=0,k="",L=!1,Y(),x&&K(b,t.submit)===null)return q();if(c>fa)return l({status:"error",step:c,filled:d,message:"Gave up after too many steps \u2014 finish this one by hand."});l({status:"filling",step:c,message:`Filling${t.multiStep?` step ${c}`:""}\u2026`});let D=je(e,{root:b,showHighlights:!0});d+=D.filled,H(`filled ${D.filled}, skipped ${D.skipped}`);let p=await Pe(e,{root:b,showHighlights:!0});if(d+=p.filled,(p.filled||p.failed.length)&&H(`comboboxes: ${p.filled} answered, ${p.failed.length} left for you`),!m&&yt(b)){l({status:"attaching",step:c,message:"Attaching your resume\u2026"});let h=await O({type:"GET_RESUME"});if(!h.ok)H("resume unavailable:",h.error);else if(!h.data)H("no resume on file");else{let T=hn(h.data,{scope:b});H("resume:",T.status),m=T.status==="attached"||T.status==="already-attached"}}if(a&&r&&f<xn)for(let h of wa(b)){if(f>=xn||o())break;l({status:"drafting",step:c,message:`Drafting an answer to "${h.label.slice(0,48)}"\u2026`});let T=await O({type:"DRAFT_ANSWER",payload:{question:h.label,...r}});if(!T.ok){H("draft failed:",T.error);break}if(!T.data.answer){H("no basis for:",h.label);continue}Ne(h.control,T.data.answer,!1)==="filled"&&(we(h.control),f+=1)}await oe(ba),v=wn(t.scope()??b);continue}if(x){if(K(b,t.submit)===null)return q();if(A+=1,A*de>=ha)return l({status:"blocked",step:c,filled:d,diagnostic:Me(b),message:"Pressed submit but the form did not accept it."});await oe(de);continue}let U=ht(b);if(U.length>0){let D=U.map(p=>`${p.kind}:${p.label}`).join("|");D!==N&&(N=D,Y(),H("waiting on:",U.map(p=>p.label)),l({status:"waiting",step:c,filled:d,blockers:U,message:`${U.length} thing${U.length===1?"":"s"} still need${U.length===1?"s":""} you.`})),await oe(de);continue}N&&(N="",Y(),H("questions answered \u2014 carrying on"));let M=K(b,t.submit);if(M){if(!i)return l({status:"ready",step:c,filled:d,message:`Ready to send \u2014 ${d} field${d===1?"":"s"} filled${m?", resume attached":""}. Review it, then submit.`});if(o())return l({status:"cancelled",step:c,message:"Stopped."});s?.(b),l({status:"submitting",step:c,message:"Sending the application\u2026"}),Ie(M),x=!0,A=0,await oe(de);continue}if(!t.multiStep)return l({status:"ready",step:c,filled:d,message:`Filled ${d} field${d===1?"":"s"}${m?" and attached your resume":""}. Check it over before you submit.`});let re=K(b,t.advance);if(!re)return H("no advance button on a step with nothing blocking it"),l({status:"blocked",step:c,filled:d,diagnostic:Me(b),message:"Could not find the button to continue. Here is everything on this step:"});if(S>=yn){let D=va(b);if(D!==k)k=D,S=0,L=!1,Y();else{L||(L=!0,H("form refused to advance; holding for a correction",Me(b)),l({status:"waiting",step:c,filled:d,blockers:[{label:"This step will not continue \u2014 check the fields for an error",kind:"invalid"}],diagnostic:Me(b),message:"The form would not move on and did not say why. Check this step for a field it is rejecting \u2014 correcting it picks the run back up."})),await oe(de);continue}}S+=1,Y(),l({status:"advancing",step:c,message:S===1?`Continuing to step ${c+1}\u2026`:`Still on step ${c} \u2014 trying again (${S} of ${yn})\u2026`}),s?.(b),Ie(re),await oe(de)}return l({status:"error",step:c,filled:d,message:"Nothing happened on this form for ten minutes \u2014 finish this one by hand."})}function Me(e){let t=[],n=e instanceof Element?e:null;if(n){let a=["role","aria-modal","data-test-modal","aria-labelledby"].map(i=>n.hasAttribute(i)?`${i}=${n.getAttribute(i)}`:"").filter(Boolean).join(" "),r="?";try{r=n.matches(":modal")?"top-layer":"in-page"}catch{}t.push(`<${n.tagName.toLowerCase()}> ${r} ${a}`.trim()),t.push(`class=${(n.className||"(none)").toString().slice(0,90)}`)}for(let a of e.querySelectorAll("input, select, textarea")){let r=a,i=r.type||a.tagName.toLowerCase();if(i==="hidden")continue;let s=i==="radio"||r.required||a.getAttribute("aria-required")==="true"||a.closest('[aria-required="true"]')!==null,l=i==="file"?`${r.files?.length??0} file`:i==="radio"||i==="checkbox"?r.checked?"checked":"unchecked":r.value?`"${r.value.slice(0,18)}"`:"EMPTY",u=[s?"req":"",_(a)?"":"hidden",a.getAttribute("role")==="combobox"?"combo":"",a.getAttribute("aria-invalid")==="true"?"INVALID":""].filter(Boolean);t.push(`${z(a,e).slice(0,26)} \xB7 ${i} \xB7 ${l}${u.length?` \xB7 ${u.join(",")}`:""}`)}let o=[...e.querySelectorAll('[class*="error" i], [class*="invalid" i], [role="alert"], [aria-live]')].filter(a=>_(a)).map(a=>(a.innerText||a.textContent||"").replace(/\s+/g," ").trim()).filter(a=>a&&a.length<160);for(let a of[...new Set(o)])t.push(`! ${a}`);for(let a of e.querySelectorAll('button, [role="button"]')){if(!_(a))continue;let r=(a.textContent||"").replace(/\s+/g," ").trim()||a.getAttribute("aria-label");r&&t.push(`[${r.slice(0,28)}]${a.disabled?" disabled":""}`)}return H("step could not advance, nothing reported as blocking:",t),t}function wn(e){let t=[...e.querySelectorAll("input, select, textarea")].filter(a=>_(a)).map(a=>a.getAttribute("name")??a.getAttribute("id")??a.tagName).join("|"),n=[...e.querySelectorAll('button, [role="button"]')].filter(a=>_(a)).map(a=>(a.textContent??"").replace(/\s+/g," ").trim().slice(0,24)).join("|");return`${(e.querySelector("h1, h2, h3")?.textContent??"").replace(/\s+/g," ").trim().slice(0,60)}#${t}#${n}`}function va(e){return[...e.querySelectorAll("input, select, textarea")].filter(t=>_(t)).map(t=>{let n=t,o=n.type?.toLowerCase();return o==="checkbox"||o==="radio"?n.checked?"1":"0":o==="file"?String(n.files?.length??0):n.value??""}).join("|")}function En(){return ce(e=>ge(e)||K(e,[...ve,..._e])!==null)}function xt(e){let t=(e.className||"").toString().toLowerCase(),n=(e.id||"").toLowerCase(),o=e.getAttribute("action")?.toLowerCase()??"",a=/jobalert|job-alert|newsletter|subscription|subscribe|alert-body|email-alert|search|login|signin|password/i;if((a.test(t)||a.test(n)||a.test(o))&&!e.querySelector('input[type="file"]')||e.querySelector('input[type="password"]'))return!0;let r=(e.querySelector('button, input[type="submit"]')?.textContent??"").trim().toLowerCase();return!!(/^(activate|subscribe|set alert|create alert|search)$/i.test(r)&&!e.querySelector('input[type="file"], input[name*="resume" i], input[name*="name" i], input[id*="name" i]'))}function Sn(){return[...document.querySelectorAll("form")].find(e=>xt(e)?!1:!!(e.querySelector('input[type="file"]')||e.querySelector('input[type="email"]')||e.querySelector('input[name*="resume" i], input[name*="email" i]')))??null}function Ea(){let e=window.location.hostname.toLowerCase(),t=e.includes("workday")||e.includes("ashbyhq")||e.includes("icims")||e.includes("taleo")||e.includes("successfactors")||e.includes("smartrecruiters")||e.includes("workable")||e.includes("teamtailor")||e.includes("bamboohr")||e.includes("zohorecruit")||e.includes("darwinbox")||e.includes("keka")||document.querySelector("[data-automation-id]")!==null,n=document.querySelectorAll('input:not([type="hidden"]), select, textarea');return!!(n.length>=1&&t||n.length>=2&&K(document,[...ve,..._e])!==null)}function kn(){return ce(ge)??Sn()??(Ea()?document:null)}function An(){return En()??Sn()??(document.querySelector("input, select, textarea")?document:null)}var ve=[/^submit application$/i,/^submit$/i,/^send application$/i,/^apply$/i,/submit your application/i],_e=[/continue to next step/i,/review your application/i,/^next$/i,/^continue$/i,/^review$/i,/^save and continue$/i,/^next step$/i],Sa={name:"single-page",scope:An,multiStep:!1,advance:[],submit:ve},vn={name:"paginated",scope:An,multiStep:!0,advance:_e,submit:ve},wt={name:"linkedin-easy-apply",scope:En,async open(){let e=document.querySelector(".jobs-search__job-details")??document,t=K(e,[/easy apply/i]);return t?(Ie(t),!0):!1},multiStep:!0,advance:_e,submit:ve};var ka=["WORKDAY","ICIMS"];function Tn(e,t){let n=t?.split("@")[0]??"";return n==="indeed"||e==="LINKEDIN"||!e?null:ka.includes(e)||["taleo","successfactors","workable"].includes(n)?vn:n==="generic"?null:Sa}var vt=50,Aa=400,ue=12e3,Ta=["#job-details",".jobs-description__content",".jobs-box__html-content",".jobs-description-content",".jobs-description","#jobDescriptionText",'[data-testid="jobDescriptionText"]','[class*="JobDescriptionText"]',".jobsearch-JobComponent-description",'[class*="job-description"]','[class*="jobDescription"]','[data-automation-id="jobPostingDescription"]','[class*="job-details"] [class*="description"]','[class*="posting-description"]','[itemprop="description"]'];function Cn(e){return!!e.closest('.jobs-search-results-list, .jobs-search-results, [class*="search-results-list"], [class*="job-card-list"]')}function Ln(e){if(!e)return null;let n=(e.innerText??e.textContent??"").split(`
`).map(o=>F(o)).filter(Boolean).join(`
`).trim();return n.length>=vt?n:null}function Ca(e){let t=e;for(let n=0;n<12;n+=1){let o=t.textContent?.length??0;if(o===0)return t;let a=[...t.children].find(r=>(r.textContent?.length??0)>=o*.9);if(!a)return t;t=a}return t}function Nn(e,t){let n=e.querySelector(".jobs-search__job-details")??e.querySelector(".jobs-search-two-pane__details")??e.querySelector(".jobs-details__main-content")??e.querySelector(".job-view-layout")??e.querySelector('[class*="job-details"]')??e.querySelector("main")??e,o=[...t.descriptionSelectors??[],...Ta];for(let r of o){let i=Array.from(n.querySelectorAll(r)).concat(Array.from(e.querySelectorAll(r))).filter(s=>!Cn(s));for(let s of i){let l=Ln(s);if(l&&l.length>=vt)return l.length>ue?`${l.slice(0,ue-1)}\u2026`:l}}let a=Zt(e);if(a&&a.length>=vt)return a.length>ue?`${a.slice(0,ue-1)}\u2026`:a;if(n!==e&&!Cn(n)){let r=Ca(n),s=r.querySelector('.jobs-search-results-list, .jobs-search-results, [class*="job-card-list"]')?null:Ln(r);if(s&&s.length>=Aa)return s.length>ue?`${s.slice(0,ue-1)}\u2026`:s}return null}var jn="https://banapply.com";var De=["left: auto","bottom: auto","margin: 0","border: 0","padding: 0","background: transparent","overflow: visible"];function Oe(e){if(typeof e.showPopover=="function")try{e.setAttribute("popover","manual"),e.showPopover()}catch{e.removeAttribute("popover")}}function Pn(e){if(e.hasAttribute("popover"))try{e.hidePopover(),e.showPopover()}catch{}}function He(e){let t=["pointerdown","mousedown","pointerup","mouseup","click","dblclick","touchstart","touchend","focusin","focusout"],n=o=>{o.stopPropagation()};for(let o of t)e.addEventListener(o,n,!1)}var Mn="banapply-banner-host",La={info:{bar:"#3b82f6",bg:"#eff6ff",fg:"#1e3a8a"},success:{bar:"#10b981",bg:"#ecfdf5",fg:"#065f46"},warning:{bar:"#f59e0b",bg:"#fffbeb",fg:"#92400e"},error:{bar:"#ef4444",bg:"#fef2f2",fg:"#991b1b"}};function Ee(){document.getElementById(Mn)?.remove()}function pe(e){Ee();let t=document.createElement("div");t.id=Mn,t.style.cssText=["position: fixed","top: 16px",`right: ${e.rightPx??16}px`,"z-index: 2147483647","width: 340px","max-width: calc(100vw - 32px)","pointer-events: none",...De].join(";");let n=t.attachShadow({mode:"closed"}),o=La[e.tone],a=document.createElement("style");a.textContent=`
    * { box-sizing: border-box; margin: 0; padding: 0; }
    .card {
      display: flex;
      gap: 12px;
      background: ${o.bg};
      border-left: 4px solid ${o.bar};
      border-radius: 8px;
      padding: 12px 14px;
      box-shadow: 0 6px 24px rgba(0, 0, 0, 0.14);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      color: ${o.fg};
      animation: slide-in 180ms ease-out;
    }
    @keyframes slide-in {
      from { opacity: 0; transform: translateX(12px); }
      to   { opacity: 1; transform: none; }
    }
    .content { flex: 1; min-width: 0; }
    .title { font-size: 13px; font-weight: 600; line-height: 1.35; }
    .body { font-size: 12px; line-height: 1.45; margin-top: 3px; opacity: 0.85; word-break: break-word; }
    .brand { font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; opacity: 0.6; margin-bottom: 4px; }


    @media (prefers-reduced-motion: reduce) { .card { animation: none; } }
  `;let r=document.createElement("div");r.className="card";let i=document.createElement("div");i.className="content";let s=document.createElement("div");s.className="brand",s.textContent="BanApply";let l=document.createElement("div");if(l.className="title",l.textContent=e.title,i.append(s,l),e.body){let d=document.createElement("div");d.className="body",d.textContent=e.body,i.append(d)}r.append(i),n.append(a,r),document.documentElement.append(t),Oe(t),He(t);let u=e.timeoutMs??(e.tone==="warning"?0:8e3);u>0&&setTimeout(Ee,u)}var Et="banapply-panel-host",Q=null,St=null,kt=null,V=!0,R={active:!1,line:null,tone:"busy",draftAnswers:!1},X=null,Se=null;function qe(){X&&(X.hidden=R.line===null,X.dataset.tone=R.tone,X.innerHTML=R.tone==="busy"?'<span class="spin"></span>':"",R.line&&X.append(document.createTextNode(R.line))),Se&&(Se.textContent=R.active?"Stop":"Apply with BanApply")}function Na(e,t){R.line=e,R.tone=t,qe()}function Rn(e){let t=document.createElement("div");t.className="card match";let n=e.matched.length+e.missing.length;if(n===0){let c=document.createElement("div");return c.className="match-line",c.textContent="No skills named in this posting that BanApply recognises.",t.append(c),t}let o=document.createElement("div");o.className="match-top";let a=document.createElement("div");a.className="dial",a.dataset.band=e.score>=70?"high":e.score>=40?"mid":"low",a.style.setProperty("--pct",String(Math.max(0,Math.min(100,e.score))));let r=document.createElement("span");r.className="dial-n",r.textContent=String(e.score),a.append(r);let i=document.createElement("div");i.className="match-verdict";let s=document.createElement("div");s.style.cssText=`font-size: 11.5px; font-weight: 800; color: ${e.score>=70?"#10b981":e.score>=40?"#ffb020":"#ff8f8f"}; margin-bottom: 2px;`,s.textContent=e.score>=70?"Strong overlap with what this posting asks for":e.score>=40?"Partial overlap with what this posting asks for":"Limited overlap with what this posting asks for";let l=document.createElement("div");l.className="match-label";let u=[`${e.matched.length} of ${n} named`];e.yearsWanted!==null&&u.push(`asks ${e.yearsWanted}+ years`);let d=document.createElement("div");d.className="match-line",d.textContent=`${u.join(" \xB7 ")}`,i.append(l,d),o.append(a,i),t.append(o);let m=6,f=(c,v,S)=>{if(c.length===0)return;let x=document.createElement("div");x.className="chips-group";let A=document.createElement("div");A.className="chips-h",A.textContent=`${S} (${c.length})`;let k=document.createElement("div");k.className="chips";let L=N=>{let P=document.createElement("span");P.className="chip",P.dataset.kind=v,P.textContent=N,k.append(P)};for(let N of c.slice(0,m))L(N);if(c.length>m){let N=document.createElement("button");N.className="chip more",N.textContent=`+${c.length-m}`,N.title=c.slice(m).join(", "),N.addEventListener("click",()=>{N.remove();for(let P of c.slice(m))L(P)}),k.append(N)}x.append(A,k),t.append(x)};return f(e.matched,"has","You have"),f(e.missing,"gap","Not in your profile"),f(e.bonus,"has","Nice-to-haves you have"),f(e.preferred,"extra","Nice to have \u2014 not required"),t}function ja(){let e=document.createElement("div");e.className="card match match-analyzing",e.style.cssText="padding: 14px; position: relative; overflow: hidden;";let t=document.createElement("div");t.className="match-top";let n=document.createElement("div");n.className="match-spinner";let o=document.createElement("div");o.className="match-verdict";let a=document.createElement("div");a.className="match-analyzing-head",a.textContent="\u2728 ANALYZING SKILLS...";let r=document.createElement("div");r.className="match-line",r.style.cssText="color: var(--dim); font-size: 11.5px;",r.textContent="Calculating shortlist match & keyword breakdown...",o.append(a,r),t.append(n,o),e.append(t);let i=document.createElement("div");i.className="chips-skeleton";for(let s=0;s<3;s++){let l=document.createElement("span");l.className="chip-skeleton",i.append(l)}return e.append(i),e}var _n={state:"idle",stage:null,message:"",questions:[],answersToSave:[],savingAnswers:!1,answersSaved:!1},g={..._n},$e=null,Dn=null;function Z(e){g={...g,...e},At()}function On(){g={..._n},At()}var In=[{key:"fill",label:"Fill"},{key:"check",label:"Check"},{key:"submit",label:"Submit"}];function At(){Je&&Fn(Je);let e=$e,t=Dn;if(!e||!t)return;if(e.innerHTML="",e.dataset.state=g.state,g.state==="running"){let a=document.createElement("div");a.className="rail";let r=In.findIndex(i=>i.key===g.stage);In.forEach((i,s)=>{let l=document.createElement("div");l.className="stage",l.dataset.state=s<r?"done":s===r?"now":"todo";let u=document.createElement("span");u.className="bead",u.textContent=s<r?"\u2713":String(s+1);let d=document.createElement("span");d.className="stage-l",d.textContent=i.label,l.append(u,d),a.append(l)}),e.append(a)}if(g.state==="needs-input"){let a=document.createElement("p");a.className="note",a.textContent="Answer the required questions in the application form and BanApply carries on by itself.",e.append(a)}if(g.state!=="idle"&&g.state!=="needs-input"&&g.message){let a=document.createElement("div");a.className="sess-msg",a.dataset.tone=g.state,a.textContent=g.message,e.append(a)}if(g.diagnostic?.length){let a=document.createElement("ul");a.className="dump";for(let i of g.diagnostic){let s=document.createElement("li");s.textContent=i,a.append(s)}e.append(a);let r=document.createElement("button");r.className="ghost",r.textContent="Copy report",r.addEventListener("click",()=>{let i=[`BanApply ${g.message}`,...g.diagnostic??[]].join(`
`);navigator.clipboard.writeText(i).then(()=>{r.textContent="Copied"},()=>{r.textContent="Select the text above and copy";let s=document.createRange();s.selectNodeContents(a);let l=window.getSelection();l?.removeAllRanges(),l?.addRange(s)})}),e.append(r)}if(g.state==="done"&&g.answersToSave.length>0&&!g.answersSaved){let a=document.createElement("div");a.className="offer";let r=document.createElement("div");r.className="offer-t",r.textContent=g.answersToSave.length===1?"Save that answer to your profile so it fills itself next time?":`Save those ${g.answersToSave.length} answers to your profile?`;let i=document.createElement("button");i.className="ghost",i.textContent=g.savingAnswers?"Saving\u2026":"Save to profile",i.disabled=g.savingAnswers,i.addEventListener("click",()=>t.onSaveAnswers(g.answersToSave)),a.append(r,i),e.append(a)}if(g.answersSaved){let a=document.createElement("p");a.className="note",a.textContent="Saved. Those questions will fill themselves from now on.",e.append(a)}let n=g.state==="running"||g.state==="needs-input";e.style.pointerEvents=n?"none":"";let o=document.createElement("button");if(o.className="fill",g.state==="running"?(o.textContent="Stop",o.style.pointerEvents="auto",o.addEventListener("click",()=>t.onCancelSession())):g.state==="needs-input"?(o.textContent="Waiting for your answers\u2026",o.disabled=!0):(o.textContent=g.state==="done"?"Apply to another":"Apply with BanApply",o.addEventListener("click",()=>t.onStartSession())),e.append(o),g.state==="idle"){let a=document.createElement("p");a.className="note",a.textContent="Fills this one application, submits it, and adds it to your tracker. One job per press.",e.append(a)}}function Hn(){!Q||!St||!kt||(V=!1,Q.repaint(St,kt))}function qn(){return!V&&Q!==null}function Be(){Q?.destroy(),Q=null,X=null,Se=null,$e=null,Je=null,Ue=void 0,document.getElementById(Et)?.remove()}var Je=null,Ue;function Fn(e){let t=document.querySelector("dialog[open]");t!==Ue&&(Ue=t,t&&Pn(e))}var Pa=`
  :host, * { box-sizing: border-box; margin: 0; padding: 0; }

  /*
   * Dark by default rather than following the page. The panel is a different
   * application sitting on top of someone else's site, and reading as distinct
   * chrome is the point \u2014 a white panel on a white ATS form looks like part of
   * the form, which is exactly the confusion to avoid before someone hits
   * submit.
   */
  /*
   * SOLID, NOT GLASS.
   *
   * This was translucent with a backdrop blur, and over a light ATS page it
   * read as washed-out grey rather than as a dark panel \u2014 the blur pulls the
   * page's brightness through no matter how heavy the tint. Every surface here
   * is opaque now, and the panel reads as its own application again, which was
   * the whole reason it is dark in the first place.
   *
   * The token names still say "glass" so the rules below did not all have to
   * change. They are ordinary solid colours: a base, one step up for raised
   * cards, one more for hover, and two line weights.
   */
  .panel {
    --ink: #070b13;
    --panel: #0d1424;
    --raised: #141e33;
    --line: #202d48;
    --text: #edf2fb;
    --dim: #94a5c4;
    --signal: #ffb020;
    --on-signal: #120c02;
    --live: #10b981;
    --warn: #ffb020;

    --glass: #0d1424;
    --glass-raised: #141e33;
    --glass-hover: #1b2946;
    --glass-line: #202d48;
    --glass-edge: #2c3c5d;

    position: relative;
    display: flex;
    flex-direction: column;
    height: 100vh;
    width: 100%;
    background: var(--glass);
    border-left: 1px solid var(--glass-edge);
    box-shadow: -20px 0 50px rgba(0, 0, 0, 0.55);
    color: var(--text);
    font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 13px;
    line-height: 1.5;
  }

  header {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 14px 16px;
    border-bottom: 1px solid var(--glass-line);
    background: linear-gradient(180deg, #090d18 0%, #070a12 100%);
    flex-shrink: 0;
  }

  .mark {
    width: 24px; height: 24px; border-radius: 7px;
    background: linear-gradient(135deg, rgba(255,176,32,0.28), rgba(11,18,32,0.95));
    border: 1px solid rgba(255,176,32,0.4);
    box-shadow: 0 0 10px rgba(255,176,32,0.2);
    display: grid; place-items: center;
    flex-shrink: 0;
  }
  .mark svg { width: 14px; height: 14px; }

  .wordmark {
    font-weight: 800;
    letter-spacing: -0.025em;
    font-size: 14.5px;
    background: linear-gradient(180deg, #ffffff 0%, #d8e2f3 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
  }

  .who {
    margin-left: auto;
    font-size: 11px;
    color: #93a6c8;
    background: rgba(255, 255, 255, 0.05);
    border: 1px solid rgba(255, 255, 255, 0.08);
    padding: 3px 9px;
    border-radius: 999px;
    max-width: 160px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .icon-btn {
    background: none; border: none; cursor: pointer;
    color: var(--dim); padding: 4px; border-radius: 5px;
    display: grid; place-items: center; flex-shrink: 0;
  }
  .icon-btn:hover { color: var(--text); background: var(--glass-hover); }
  .icon-btn svg { width: 15px; height: 15px; }

  /* The only scrolling region: the header and the action stay put. */
  .body {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overscroll-behavior: contain;
    padding: 12px 14px;
    display: flex;
    flex-direction: column;
    gap: 9px;
  }

  /*
   * A thin, dark scrollbar for the times it is genuinely needed.
   *
   * The chip lists have no fixed height, so no amount of tightening guarantees
   * a fit at every window size \u2014 the goal is that scrolling is rare and, when
   * it happens, does not look like the panel broke. The default is a pale
   * chunky bar that reads as the host page's chrome bleeding through.
   */
  .body::-webkit-scrollbar { width: 8px; }
  .body::-webkit-scrollbar-track { background: transparent; }
  .body::-webkit-scrollbar-thumb {
    background: var(--glass-edge);
    border-radius: 999px;
    border: 2px solid var(--glass);
  }
  .body::-webkit-scrollbar-thumb:hover { background: var(--dim); }
  .body { scrollbar-width: thin; scrollbar-color: var(--glass-edge) transparent; }

  .card {
    background: var(--glass-raised);
    border: 1px solid var(--glass-line);
    border-radius: 12px;
    padding: 12px 13px;
    box-shadow: 0 4px 14px rgba(0,0,0,0.24), inset 0 1px 0 rgba(255, 255, 255, 0.08);
    transition: border-color 160ms ease, background-color 160ms ease;
  }

  .role { font-size: 14.5px; font-weight: 700; letter-spacing: -0.015em; color: #f3f7fc; line-height: 1.35; }
  .meta { color: var(--dim); font-size: 12px; margin-top: 4px; }

  .lamp-row {
    display: flex; align-items: center; gap: 8px;
    margin-top: 9px; padding-top: 9px;
    border-top: 1px solid var(--glass-line);
    font-size: 11.5px; color: var(--dim);
  }
  .lamp {
    width: 7px; height: 7px; border-radius: 50%;
    background: var(--live); flex-shrink: 0;
    box-shadow: 0 0 8px rgba(16, 185, 129, 0.6);
  }

  /* Duplicate warning. Amber not red: applying twice is worth knowing about,
     not an error, and red here would read as "something broke". */
  .warn {
    border-color: rgba(255, 176, 32, 0.4);
    background: rgba(255, 176, 32, 0.09);
  }
  .warn .role { color: var(--signal); font-size: 13px; }

  .action {
    padding: 13px 16px;
    border-top: 1px solid var(--glass-line);
    background: var(--ink);
    flex-shrink: 0;
  }

  .fill {
    width: 100%;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    background: linear-gradient(135deg, #ffc857 0%, #ffb020 100%);
    color: var(--on-signal);
    border: none; border-radius: 11px;
    padding: 13.5px 18px;
    font: inherit; font-size: 14px; font-weight: 750;
    cursor: pointer;
    box-shadow:
      0 6px 20px rgba(255, 176, 32, 0.32),
      inset 0 1px 0 rgba(255, 255, 255, 0.4);
    transition: filter 140ms ease, transform 140ms ease, box-shadow 140ms ease;
  }
  .fill:hover:not(:disabled) {
    filter: brightness(1.08);
    transform: translateY(-1px);
    box-shadow: 0 8px 24px rgba(255, 176, 32, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.4);
  }
  .fill:active:not(:disabled) { transform: translateY(0); }
  .fill:disabled { opacity: 0.55; cursor: default; }
  .fill svg { width: 15px; height: 15px; }

  .ghost {
    width: 100%;
    background: var(--glass-raised);
    color: var(--text);
    border: 1px solid var(--glass-line);
    border-radius: 11px;
    padding: 11px 15px;
    font: inherit; font-size: 13px; font-weight: 600;
    cursor: pointer;
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06);
    transition: background 140ms ease, border-color 140ms ease, transform 140ms ease;
  }
  .ghost:hover:not(:disabled) {
    background: var(--glass-hover);
    border-color: var(--glass-edge);
    transform: translateY(-1px);
  }
  .ghost:disabled { opacity: 0.5; cursor: default; }

  .toggle {
    display: flex; align-items: center; gap: 8px;
    margin-top: 10px;
    font-size: 12px; color: var(--dim);
    cursor: pointer;
  }
  .toggle input { accent-color: var(--signal); width: 14px; height: 14px; cursor: pointer; }

  .note { font-size: 11.5px; color: var(--dim); }

  /* Match ---------------------------------------------------------------- */

  .match-head { font-size: 12.5px; font-weight: 650; margin-bottom: 9px; }
  .match-err { margin-top: 8px; font-size: 11.5px; color: #ff9b9b; line-height: 1.4; }

  .match-top { display: flex; align-items: center; gap: 12px; }

  /*
   * A ring rather than a bar: a bar reads as progress toward something, and
   * there is nothing here to complete. conic-gradient needs no SVG and no
   * animation frame.
   */
  .dial {
    --pct: 0;
    width: 44px; height: 44px; border-radius: 50%;
    flex-shrink: 0;
    display: grid; place-items: center;
    background: conic-gradient(var(--band) calc(var(--pct) * 1%), rgba(255,255,255,0.07) 0);
    position: relative;
  }
  .dial::after {
    content: ''; position: absolute; inset: 4px;
    border-radius: 50%; background: var(--glass-raised);
  }
  .dial-n { position: relative; z-index: 1; font-size: 13.5px; font-weight: 700; }
  .dial[data-band='high'] { --band: var(--live); }
  .dial[data-band='mid']  { --band: var(--signal); }
  .dial[data-band='low']  { --band: #ff8f8f; }
  .dial[data-band='high'] .dial-n { color: var(--live); }
  .dial[data-band='mid'] .dial-n  { color: var(--signal); }
  .dial[data-band='low'] .dial-n  { color: #ff8f8f; }

  .match-verdict { min-width: 0; }
  .match-label {
    font-size: 9.5px; letter-spacing: 0.07em; text-transform: uppercase;
    color: var(--dim); font-weight: 700;
  }
  .match-line { font-size: 12px; line-height: 1.4; margin-top: 3px; }

  .chips-group { margin-top: 9px; }
  .chips-h { font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; color: var(--dim); font-weight: 700; }
  .chips { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 5px; }
  .chip {
    font-size: 10.5px; line-height: 1.25;
    padding: 3px 7px; border-radius: 999px;
    border: 1px solid var(--glass-line);
  }
  /* The overflow control. A button, so it is reachable by keyboard. */
  .chip.more {
    background: transparent; color: var(--dim);
    font: inherit; font-size: 10.5px; cursor: pointer;
  }
  .chip.more:hover { color: var(--text); border-color: var(--glass-edge); }
  .chip[data-kind='has'] { background: rgba(63,207,142,0.12); border-color: rgba(63,207,142,0.32); color: #9fe6c4; }
  .chip[data-kind='gap'] { background: rgba(255,176,32,0.10); border-color: rgba(255,176,32,0.30); color: #ffd08a; }
  /* Neutral on purpose: an unmet nice-to-have is not a gap, and colouring it
     like one is what made a full-marks profile look half-qualified. */
  .chip[data-kind='extra'] { background: rgba(124,141,166,0.10); border-color: rgba(124,141,166,0.28); color: #b3c0d4; }

  .match .note { margin-top: 10px; }

  /* Bulk run -------------------------------------------------------------- */

  /* Not a card: it is the action bar's own content, not something inside it. */
  .run { display: flex; flex-direction: column; gap: 8px; }
  .run > .fill { margin-top: 0; }

  /* Stage rail */
  .rail { display: flex; align-items: center; justify-content: space-between; }
  .stage { display: flex; flex-direction: column; align-items: center; gap: 4px; flex: 1; }
  .bead {
    width: 21px; height: 21px; border-radius: 50%;
    display: grid; place-items: center;
    font-size: 10px; font-weight: 700;
    border: 1px solid var(--glass-line);
    color: var(--dim);
  }
  .stage-l { font-size: 9.5px; color: var(--dim); }
  .stage[data-state='done'] .bead { background: rgba(63,207,142,0.18); border-color: rgba(63,207,142,0.5); color: var(--live); }
  .stage[data-state='done'] .stage-l { color: var(--live); }
  .stage[data-state='now'] .bead {
    background: var(--signal); border-color: transparent; color: var(--on-signal);
    box-shadow: 0 0 0 4px rgba(255,176,32,0.16);
  }
  .stage[data-state='now'] .stage-l { color: var(--signal); font-weight: 700; }

  /* The questions the form still wants. Amber, not red: nothing is broken. */
  .ask-head { font-size: 12.5px; font-weight: 650; color: var(--signal); }
  .asks { list-style: none; margin-top: 8px; display: flex; flex-direction: column; gap: 5px; }
  .asks li {
    font-size: 12px; line-height: 1.35;
    padding: 7px 9px; border-radius: 8px;
    background: rgba(255,176,32,0.10);
    border: 1px solid rgba(255,176,32,0.28);
  }
  .asks li[data-kind='invalid'] {
    background: rgba(239,68,68,0.10);
    border-color: rgba(239,68,68,0.3);
  }
  .asks li[data-kind='invalid']::before { content: '\u26A0\uFE0E  '; opacity: 0.8; }

  /* Diagnostic dump: only rendered when a run stalled without a cause. */
  .dump {
    list-style: none; margin-top: 8px;
    max-height: 260px; overflow-y: auto;
    border: 1px solid rgba(255,255,255,0.12); border-radius: 8px;
    padding: 6px 8px;
  }
  .dump li {
    font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, monospace);
    font-size: 10.5px; line-height: 1.45;
    word-break: break-word; opacity: 0.85;
  }

  .sess-msg { font-size: 12px; line-height: 1.4; color: var(--dim); }
  .sess-msg[data-tone='done']  { color: var(--live); font-weight: 600; }
  .sess-msg[data-tone='error'] { color: #ff9b9b; }

  .offer {
    margin-top: 11px; padding: 10px;
    border: 1px solid var(--glass-line); border-radius: 10px;
    background: var(--glass-raised);
  }
  .offer-t { font-size: 12px; line-height: 1.4; margin-bottom: 8px; }

  .run .fill { margin-top: 11px; }

  /* Match ---------------------------------------------------------------- */

  .match-head { font-size: 12.5px; font-weight: 650; margin-bottom: 9px; }
  .match-err { margin-top: 8px; font-size: 11.5px; color: #ff9b9b; line-height: 1.4; }

  .match-top { display: flex; align-items: center; gap: 12px; }

  /*
   * A ring rather than a bar: a bar reads as progress toward something, and
   * there is nothing here to complete. conic-gradient needs no SVG and no
   * animation frame.
   */
  .dial {
    --pct: 0;
    width: 54px; height: 54px; border-radius: 50%;
    flex-shrink: 0;
    display: grid; place-items: center;
    background: conic-gradient(var(--band) calc(var(--pct) * 1%), rgba(255,255,255,0.07) 0);
    position: relative;
  }
  .dial::after {
    content: ''; position: absolute; inset: 5px;
    border-radius: 50%; background: var(--glass-raised);
  }
  .dial-n { position: relative; z-index: 1; font-size: 15px; font-weight: 700; }
  .dial[data-band='high'] { --band: var(--live); }
  .dial[data-band='mid']  { --band: var(--signal); }
  .dial[data-band='low']  { --band: #ff8f8f; }
  .dial[data-band='high'] .dial-n { color: var(--live); }
  .dial[data-band='mid'] .dial-n  { color: var(--signal); }
  .dial[data-band='low'] .dial-n  { color: #ff8f8f; }

  .match-verdict { min-width: 0; }
  .match-label {
    font-size: 9.5px; letter-spacing: 0.07em; text-transform: uppercase;
    color: var(--dim); font-weight: 700;
  }
  .match-line { font-size: 12px; line-height: 1.4; margin-top: 3px; }

  .chips-group { margin-top: 11px; }
  .chips-h { font-size: 10px; letter-spacing: 0.06em; text-transform: uppercase; color: var(--dim); font-weight: 700; }
  .chips { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 6px; }
  .chip {
    font-size: 11px; line-height: 1.3;
    padding: 4px 8px; border-radius: 999px;
    border: 1px solid var(--glass-line);
  }
  .chip[data-kind='has'] { background: rgba(63,207,142,0.12); border-color: rgba(63,207,142,0.32); color: #9fe6c4; }
  .chip[data-kind='gap'] { background: rgba(255,176,32,0.10); border-color: rgba(255,176,32,0.30); color: #ffd08a; }
  /* Neutral on purpose: an unmet nice-to-have is not a gap, and colouring it
     like one is what made a full-marks profile look half-qualified. */
  .chip[data-kind='extra'] { background: rgba(124,141,166,0.10); border-color: rgba(124,141,166,0.28); color: #b3c0d4; }

  @keyframes jpSpin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
  @keyframes jpPulse {
    0%, 100% { opacity: 0.45; }
    50% { opacity: 1; }
  }
  @keyframes jpShimmer {
    0% { background-position: -150px 0; }
    100% { background-position: 150px 0; }
  }

  .match-spinner {
    width: 44px; height: 44px; border-radius: 50%;
    flex-shrink: 0;
    border: 3px solid rgba(255, 176, 32, 0.15);
    border-top-color: #ffb020;
    border-right-color: #10b981;
    animation: jpSpin 0.9s linear infinite;
  }

  .match-analyzing-head {
    font-size: 11px; font-weight: 800;
    letter-spacing: 0.06em; text-transform: uppercase;
    color: #ffb020;
    animation: jpPulse 1.4s ease-in-out infinite;
  }

  .chips-skeleton {
    display: flex; gap: 6px; margin-top: 10px;
  }

  .chip-skeleton {
    height: 20px; width: 60px; border-radius: 999px;
    background: linear-gradient(90deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.15) 50%, rgba(255,255,255,0.05) 100%);
    background-size: 300px 100%;
    animation: jpShimmer 1.4s infinite;
  }
  .chip-skeleton:nth-child(2) { width: 80px; }
  .chip-skeleton:nth-child(3) { width: 55px; }

  .match .note { margin-top: 10px; }

  /* Bulk run -------------------------------------------------------------- */

  /* Not a card: it is the action bar's own content, not something inside it. */
  .run { display: flex; flex-direction: column; gap: 10px; }
  .run > .fill { margin-top: 0; }

  /* Stage rail */
  .rail { display: flex; align-items: center; justify-content: space-between; }
  .stage { display: flex; flex-direction: column; align-items: center; gap: 4px; flex: 1; }
  .bead {
    width: 21px; height: 21px; border-radius: 50%;
    display: grid; place-items: center;
    font-size: 10px; font-weight: 700;
    border: 1px solid var(--glass-line);
    color: var(--dim);
  }
  .stage-l { font-size: 9.5px; color: var(--dim); }
  .stage[data-state='done'] .bead { background: rgba(63,207,142,0.18); border-color: rgba(63,207,142,0.5); color: var(--live); }
  .stage[data-state='done'] .stage-l { color: var(--live); }
  .stage[data-state='now'] .bead {
    background: var(--signal); border-color: transparent; color: var(--on-signal);
    box-shadow: 0 0 0 4px rgba(255,176,32,0.16);
  }
  .stage[data-state='now'] .stage-l { color: var(--signal); font-weight: 700; }

  /* The questions the form still wants. Amber, not red: nothing is broken. */
  .ask-head { font-size: 12.5px; font-weight: 650; color: var(--signal); }
  .asks { list-style: none; margin-top: 8px; display: flex; flex-direction: column; gap: 5px; }
  .asks li {
    font-size: 12px; line-height: 1.35;
    padding: 7px 9px; border-radius: 8px;
    background: rgba(255,176,32,0.10);
    border: 1px solid rgba(255,176,32,0.28);
  }
  .asks li[data-kind='invalid'] {
    background: rgba(239,68,68,0.10);
    border-color: rgba(239,68,68,0.3);
  }
  .asks li[data-kind='invalid']::before { content: '\u26A0\uFE0E  '; opacity: 0.8; }

  /* Diagnostic dump: only rendered when a run stalled without a cause. */
  .dump {
    list-style: none; margin-top: 8px;
    max-height: 260px; overflow-y: auto;
    border: 1px solid rgba(255,255,255,0.12); border-radius: 8px;
    padding: 6px 8px;
  }
  .dump li {
    font-family: var(--font-mono, ui-monospace, SFMono-Regular, Menlo, monospace);
    font-size: 10.5px; line-height: 1.45;
    word-break: break-word; opacity: 0.85;
  }

  .sess-msg { font-size: 12px; line-height: 1.4; color: var(--dim); }
  .sess-msg[data-tone='done']  { color: var(--live); font-weight: 600; }
  .sess-msg[data-tone='error'] { color: #ff9b9b; }

  .offer {
    margin-top: 11px; padding: 10px;
    border: 1px solid var(--glass-line); border-radius: 10px;
    background: var(--glass-raised);
  }
  .offer-t { font-size: 12px; line-height: 1.4; margin-bottom: 8px; }

  .run .fill { margin-top: 11px; }

  /* Resume ---------------------------------------------------------------- */

  .resume { display: flex; align-items: center; gap: 10px; }

  .doc {
    width: 30px; height: 34px; border-radius: 5px; flex-shrink: 0;
    display: grid; place-items: center;
    background: linear-gradient(160deg, rgba(255,176,32,0.18), rgba(255,255,255,0.04));
    border: 1px solid rgba(255,176,32,0.26);
    color: var(--signal);
    font-size: 8.5px; font-weight: 800; letter-spacing: 0.04em;
    text-transform: uppercase;
  }

  /* min-width:0 or a long filename pushes the button off the panel. */
  .resume-meta { min-width: 0; flex: 1; }
  .resume-name {
    font-size: 12.5px; font-weight: 600;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .resume-sub { font-size: 11px; color: var(--dim); margin-top: 1px; }

  .attach {
    flex-shrink: 0;
    background: var(--glass-raised);
    color: var(--text);
    border: 1px solid var(--glass-line);
    border-radius: 8px;
    padding: 7px 11px;
    font: inherit; font-size: 12px; font-weight: 600;
    cursor: pointer;
    transition: background 140ms ease, border-color 140ms ease;
  }
  .attach:hover:not(:disabled) { background: var(--glass-hover); border-color: var(--glass-edge); }
  .attach:disabled { opacity: 0.55; cursor: default; }
  .attach[data-done='1'] { color: var(--live); border-color: rgba(63,207,142,0.35); }

  .linkish {
    background: none; border: none; padding: 0;
    color: var(--signal); font: inherit; font-size: 12px; font-weight: 600;
    cursor: pointer; text-decoration: underline; text-underline-offset: 2px;
  }

  /* Run status ----------------------------------------------------------- */

  .status {
    display: flex;
    gap: 8px;
    align-items: flex-start;
    border-radius: 8px;
    padding: 10px 11px;
    font-size: 12px;
    line-height: 1.45;
  }
  .status[data-tone='busy']    { background: rgba(74,168,216,0.12); color: #a9d6ee; }
  .status[data-tone='blocked'] { background: rgba(255,176,32,0.12); color: #ffd08a; }
  .status[data-tone='ready']   { background: rgba(63,207,142,0.12); color: #9fe6c4; }

  /* Spins only while the run is active, and never under reduced motion. */
  .spin {
    width: 12px; height: 12px; flex-shrink: 0; margin-top: 2px;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
  }
  @media (prefers-reduced-motion: no-preference) {
    .status[data-tone='busy'] .spin { animation: rot 700ms linear infinite; }
  }
  @keyframes rot { to { transform: rotate(360deg); } }

  .apply {
    width: 100%;
    display: flex; align-items: center; justify-content: center; gap: 8px;
    background: transparent;
    color: var(--signal);
    border: 1px solid var(--signal);
    border-radius: 8px;
    padding: 11px 16px;
    font: inherit; font-size: 13.5px; font-weight: 700;
    cursor: pointer;
    margin-top: 9px;
  }
  .apply:hover:not(:disabled) { background: rgba(255,176,32,0.1); }
  .apply:disabled { opacity: 0.5; cursor: default; }

  /* Auth form ------------------------------------------------------------ */

  .auth-card { display: flex; flex-direction: column; gap: 11px; margin-top: 4px; padding: 14px 15px; }
  .auth-head { font-size: 14px; font-weight: 750; color: #ffffff; letter-spacing: -0.01em; }

  .field { display: flex; flex-direction: column; gap: 6px; }
  .field label { font-size: 11.5px; color: var(--dim); font-weight: 600; }
  .field input {
    background: var(--ink);
    border: 1px solid var(--glass-line);
    border-radius: 9px;
    padding: 11px 13px;
    color: var(--text);
    font: inherit; font-size: 13px;
    transition: border-color 140ms ease, box-shadow 140ms ease;
  }
  .field input:focus-visible {
    outline: 2px solid var(--signal);
    outline-offset: 1px;
    border-color: transparent;
    box-shadow: 0 0 10px rgba(255,176,32,0.25);
  }
  .field input::placeholder { color: #617392; }

  .err {
    background: rgba(239, 68, 68, 0.14);
    border: 1px solid rgba(239, 68, 68, 0.38);
    color: #fca5a5;
    border-radius: 9px;
    padding: 10px 12px;
    font-size: 12px;
    line-height: 1.4;
  }

  .switch {
    background: none; border: none; padding: 0;
    color: var(--signal); font: inherit; font-size: 12.5px; font-weight: 600;
    cursor: pointer; text-decoration: underline; text-underline-offset: 2px; align-self: flex-start;
  }

  .foot {
    display: flex; gap: 10px; align-items: center; justify-content: space-between;
    padding: 12px 16px;
    border-top: 1px solid var(--glass-line);
    background: var(--ink);
    flex-shrink: 0;
  }
  .link {
    background: none; border: none; padding: 0;
    color: var(--dim); font: inherit; font-size: 11.5px; font-weight: 500;
    cursor: pointer; text-decoration: underline; text-underline-offset: 2px;
  }
  .link:hover { color: var(--text); }

  /*
   * The resting state: a launcher docked flush to the right edge.
   * Premium dark glow styling matching jobpilot website palette (#0d1424 / #ffb020).
   */
  .handle {
    position: absolute;
    top: 35%; right: 0;
    transform: translateY(-50%);
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px 10px 14px;
    background: linear-gradient(135deg, #0d1424 0%, #141e33 100%);
    color: #ffffff;
    border: 1px solid rgba(255, 176, 32, 0.45);
    border-right: none;
    border-top-left-radius: 999px;
    border-bottom-left-radius: 999px;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    cursor: pointer;
    font: inherit;
    font-size: 13px;
    font-weight: 750;
    letter-spacing: -0.01em;
    box-shadow: 0 4px 20px rgba(255, 176, 32, 0.4), -4px 0 15px rgba(0, 0, 0, 0.5);
    transition: transform 160ms cubic-bezier(0.22, 1, 0.36, 1), box-shadow 160ms ease, filter 160ms ease;
  }
  .handle:hover {
    transform: translateY(-50%) translateX(-2px);
    box-shadow: 0 6px 25px rgba(255, 176, 32, 0.6), -6px 0 20px rgba(0, 0, 0, 0.6);
    filter: brightness(1.1);
  }
  .handle:active { transform: translateY(-50%) translateX(0); }
  .handle svg {
    width: 17px; height: 17px;
    flex-shrink: 0;
    color: #ffb020;
    filter: drop-shadow(0 0 6px rgba(255, 176, 32, 0.8));
  }

  /* Count of fillable fields \u2014 highlighted badge. */
  .handle .count {
    background: rgba(255, 176, 32, 0.2);
    border: 1px solid rgba(255, 176, 32, 0.4);
    color: #ffb020;
    border-radius: 999px;
    padding: 1px 8px;
    font-size: 11px;
    font-weight: 800;
    font-variant-numeric: tabular-nums;
  }

  /* One slow sweep so it registers as new without becoming a blinking
     ornament on every page. */
  @media (prefers-reduced-motion: no-preference) {
    [data-first] .handle { animation: pop 260ms cubic-bezier(0.22, 1, 0.36, 1); }
    @keyframes pop {
      from { opacity: 0; transform: translateY(-50%) translateX(20px); }
    }
  }

  @media (prefers-reduced-motion: no-preference) {
    [data-first] .panel { animation: slide 220ms cubic-bezier(0.22, 1, 0.36, 1); }
    @keyframes slide { from { transform: translateX(100%); } }
  }
`,Fe='<svg viewBox="0 0 24 24" fill="currentColor"><path d="M13 2L4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5z"/></svg>',$n='<svg viewBox="0 0 32 32" fill="none"><path d="M16 7l7 9-7 9-7-9z" fill="#FFB020"/></svg>',Jn='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M9 6l6 6-6 6"/></svg>',Ma='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';function Ia(e,t,n){let o=document.createElement("div");o.className="panel",o.setAttribute("role","complementary"),o.setAttribute("aria-label","BanApply");let a=document.createElement("header"),r=document.createElement("span");r.className="mark",r.innerHTML=$n;let i=document.createElement("span");i.className="wordmark",i.textContent="BanApply";let s=document.createElement("span");s.className="who",s.textContent="Sign in";let l=document.createElement("button");l.className="icon-btn",l.setAttribute("aria-label","Collapse"),l.innerHTML=Jn,l.addEventListener("click",n),a.append(r,i,s,l);let u=document.createElement("div");u.className="body";let d=document.createElement("div");d.className="card";let m=document.createElement("div");m.className="role",m.textContent=e.job.title??"This posting";let f=document.createElement("div");f.className="meta",f.textContent=[e.job.company,e.job.location].filter(Boolean).join(" \xB7 "),d.append(m,f);let c=document.createElement("div");c.className="lamp-row",c.dataset.state="ready",c.innerHTML='<span class="lamp"></span>',c.append(document.createTextNode("Sign in on BanApply website to auto-apply")),d.append(c),u.append(d),e.match&&u.append(Rn(e.match));let v=document.createElement("div");v.className="card auth-card";let S=document.createElement("div");S.className="auth-head",S.textContent="Sign in to Auto Apply";let x=document.createElement("p");x.className="note",x.textContent="Sign in or create your BanApply account on our web app to autofill applications with one click and track every role in your dashboard.",v.append(S,x),u.append(v);let A=document.createElement("div");A.className="action";let k=document.createElement("button");k.className="fill",k.innerHTML=Fe;let L=document.createElement("span");return L.textContent="Sign in to Auto Apply",k.append(L),k.addEventListener("click",()=>{window.open(`${jn}/login`,"_blank")}),A.append(k),o.append(a,u,A),o}async function Tt(e,t){if(St=e,kt=t,Q&&document.getElementById(Et)){Q.repaint(e,t);return}Be();let n=document.createElement("div");n.id=Et,n.style.cssText=["position: fixed","top: 0","right: 0","height: 100vh","width: 372px","max-width: 100vw","z-index: 2147483647","pointer-events: none",...De].join(";");let o=n.attachShadow({mode:"closed"}),a=document.createElement("style");a.textContent=Pa;let r=document.createElement("div");r.style.cssText="pointer-events: auto; height: 100%;",r.setAttribute("data-first","");let i=e,s=t,l=()=>{if(r.innerHTML="",X=null,Se=null,$e=null,V){let p=document.createElement("button");p.className="handle";let h=i.coverage.fillable>0,T=h?`Autofill ${i.coverage.fillable} fields with BanApply`:"Open BanApply \u2014 save this job or check for duplicates";if(p.setAttribute("aria-label",T),p.title=T,p.innerHTML=Fe,p.append(document.createTextNode(h?"Autofill":"BanApply")),h){let I=document.createElement("span");I.className="count",I.textContent=String(i.coverage.fillable),p.append(I)}p.addEventListener("click",()=>{V=!1,l()}),r.style.pointerEvents="none",p.style.pointerEvents="auto",r.append(p),n.style.width="200px";return}if(r.style.pointerEvents="auto",n.style.width="372px",!i.authenticated){r.append(Ia(e,t,()=>{V=!0,l()}));return}let d=document.createElement("div");d.className="panel",d.setAttribute("role","complementary"),d.setAttribute("aria-label","BanApply");let m=document.createElement("header"),f=document.createElement("span");f.className="mark",f.innerHTML=$n;let c=document.createElement("span");c.className="wordmark",c.textContent="BanApply";let v=document.createElement("span");v.className="who",v.textContent=i.email??"";let S=document.createElement("button");S.className="icon-btn",S.setAttribute("aria-label","Collapse"),S.innerHTML=Jn,S.addEventListener("click",()=>{V=!0,l()});let x=document.createElement("button");x.className="icon-btn",x.setAttribute("aria-label","Close"),x.title="Close",x.innerHTML=Ma,x.addEventListener("click",()=>{V=!0,l()}),m.append(f,c,v,S,x);let A=document.createElement("div");A.className="body";let k=document.createElement("div");k.className="card";let L=document.createElement("div");L.className="role",L.textContent=i.job.title??"This posting";let N=document.createElement("div");N.className="meta",N.textContent=[i.job.company,i.job.location].filter(Boolean).join(" \xB7 "),k.append(L,N);let P=document.createElement("div");P.className="lamp-row";let Y=i.isExternalJob?{state:"no-form",text:"Apply on company website \u2014 auto-apply is available for Naukri Easy Apply jobs"}:i.hasForm?i.coverage.fillable===0?{state:"no-match",text:`Nothing here matches your profile (${i.coverage.total} field${i.coverage.total===1?"":"s"})`}:{state:"ready",text:`${i.coverage.fillable} of ${i.coverage.total} fields can be filled`}:i.canApply?{state:"ready",text:"Ready to apply \u2014 the form opens when you start"}:{state:"no-form",text:"No application form on this page"};if(P.dataset.state=Y.state,P.innerHTML='<span class="lamp"></span>',P.append(document.createTextNode(Y.text)),k.append(P),A.append(k),i.duplicate){let p=document.createElement("div");p.className="card warn";let h=document.createElement("div");h.className="role",h.textContent="You already applied to this role";let T=document.createElement("div");T.className="meta";let I=It(i.duplicate.appliedAt)||(i.duplicate.daysAgo!==null?`${i.duplicate.daysAgo} days ago`:"earlier");T.textContent=`${i.duplicate.title} at ${i.duplicate.companyName} \xB7 ${I} \xB7 ${i.duplicate.status.toLowerCase()}`,p.append(h,T),A.append(p)}let q=document.createElement("button");if(q.className="ghost",q.textContent="Save this job",q.addEventListener("click",()=>{q.disabled=!0,q.textContent="Saving\u2026",s.onSave().then(p=>{q.textContent=p?"Saved to your tracker":"Could not save",p||(q.disabled=!1)})}),A.append(q),i.match&&g.state==="idle")A.append(Rn(i.match));else if(i.isAnalyzingMatch&&g.state==="idle")A.append(ja());else if(!i.match&&g.state==="idle"){let p=document.createElement("div");p.className="card match",p.style.cssText="padding: 12px 14px;";let h=document.createElement("div");h.style.cssText="font-size: 11px; font-weight: 800; color: var(--dim); letter-spacing: 0.06em; text-transform: uppercase; margin-bottom: 4px;",h.textContent="\u{1F3AF} SKILLS MATCHING";let T=document.createElement("p");if(T.style.cssText="font-size: 11.5px; color: var(--dim); line-height: 1.4;",T.textContent=i.authenticated?"Could not read this posting\u2019s description, so there is nothing to compare yet.":"Add your skills in your BanApply web profile to see how this posting compares.",p.append(h,T),i.matchDiagnostic?.length){let I=document.createElement("pre");I.style.cssText="margin-top: 8px; font-size: 10px; line-height: 1.45; color: var(--dim); white-space: pre-wrap; word-break: break-all; opacity: 0.75; max-height: 88px; overflow: auto;",I.textContent=i.matchDiagnostic.join(`
`),p.append(I)}A.append(p)}let b=document.createElement("div");if(b.className="action",i.isExternalJob){let p=document.createElement("button");p.className="fill",p.disabled=!0,p.textContent="Apply on Company Site (Unsupported)";let h=document.createElement("p");h.className="note",h.style.marginTop="8px",h.textContent="Auto-apply is available for Naukri Easy Apply jobs. Save this job to track your application.",b.append(p,h)}else if(i.canApply){let p=document.createElement("div");p.className="run",$e=p,Dn=s,At(),b.append(p)}let U=i.hasForm&&!i.canApply,M=document.createElement("button");M.className="fill",M.innerHTML=Fe,M.append(document.createTextNode(i.coverage.fillable>0?`Fill ${i.coverage.fillable} field${i.coverage.fillable===1?"":"s"}`:i.hasForm?"Nothing to fill here":"No form to fill")),M.disabled=i.coverage.fillable===0;let re=document.createElement("label");re.className="toggle";let D=document.createElement("input");if(D.type="checkbox",re.append(D,document.createTextNode("Replace values I already typed")),M.addEventListener("click",()=>{M.disabled=!0,M.textContent="Filling\u2026",s.onFill(D.checked).then(p=>{M.textContent=p.filled>0?`Filled ${p.filled}${p.unanswered>0?` \xB7 ${p.unanswered} left for you`:""}`:"Nothing was filled",setTimeout(()=>{M.disabled=!1,M.innerHTML=Fe,M.append(document.createTextNode("Fill again"))},2600)})}),U&&b.append(M,re),i.canAutoApply&&!i.canApply){let p=document.createElement("div");p.className="status";let h=document.createElement("button");h.className="apply";let T=document.createElement("label");T.className="toggle";let I=document.createElement("input");I.type="checkbox",I.checked=R.draftAnswers,I.addEventListener("change",()=>{R.draftAnswers=I.checked}),T.append(I,document.createTextNode("Draft long answers with AI")),X=p,Se=h,qe(),h.addEventListener("click",()=>{if(R.active){s.onCancelAutoApply();return}R={...R,active:!0,line:null,tone:"busy"},qe(),s.onAutoApply(Na,R.draftAnswers).finally(()=>{R.active=!1,qe()})});let tt=document.createElement("p");tt.className="note",tt.textContent="Fills the form, attaches your resume, and stops at submit. You press submit.",b.append(h,T,tt,p)}d.append(m,A,b),r.append(d)};l(),o.append(a,r),requestAnimationFrame(()=>r.removeAttribute("data-first")),document.documentElement.append(n),Je=n,Oe(n),He(n),Ue=document.querySelector("dialog[open]");let u=d=>{d.key==="Escape"&&(V=!0,l())};window.addEventListener("keydown",u),Q={destroy:()=>window.removeEventListener("keydown",u),repaint:(d,m)=>{i=d,s=m,l(),Fn(n)}}}function Ra(...e){console.info("[jobpilot] session:",...e)}var ze=[],Ge=!1,Ye=!1;function Ct(){return Ge}function Un(){Ye=!0}function Bn(){ze=[],ke=[],Ge=!1,Ye=!1}function _a(e,t){if(t.length===0)return[];let n=new Set(t),o=[],a=e.querySelectorAll("input, select, textarea");for(let r of a){let i=r.type;if(i==="hidden"||i==="file"||i==="password")continue;let s=z(r,e);if(!n.has(s))continue;let l;if(i==="radio"||i==="checkbox"){let u=r;if(!u.checked)continue;l=Da(u)||u.value}else l=String(r.value??"").trim();l&&(o.some(u=>u.label===s)||o.push({label:s,answer:l}))}return o}function Da(e){return(e.closest("label")?.textContent??(e.id?e.ownerDocument.querySelector(`label[for="${CSS.escape(e.id)}"]`)?.textContent:null)??"").replace(/\s+/g," ").trim()}async function zn(e){Ge=!0,Ye=!1;let t=o=>(Ra(o.state,o.stage??"-",o.message),e.onProgress(o),o),n=o=>(Ge=!1,t(o));try{let o=await Re({profile:e.profile,flow:e.flow,draftAnswers:e.draftAnswers,autoSubmit:!0,isCancelled:()=>Ye,job:(()=>{let a=e.readCurrentJob();return a?{title:a.title,company:a.company,jobUrl:a.jobUrl}:void 0})(),onProgress:a=>{if(a.status==="waiting"){ze=(a.blockers??[]).map(r=>r.label),t({state:"needs-input",stage:"check",message:a.message,questions:a.blockers??[],answersToSave:[]});return}t({state:"running",stage:a.status==="submitting"?"submit":a.status==="filling"?"fill":"check",message:a.message,questions:[],answersToSave:[]})},snapshotAnswers:a=>{for(let r of _a(a,ze))ke.some(i=>i.label===r.label)||ke.push(r)}});if(o.status==="submitted"){let a=e.readCurrentJob(),r=!0;a&&(r=await e.onApplied(a));let i=ke;return ke=[],ze=[],n({state:"done",stage:null,message:r?"Applied \u2014 added to your tracker.":"Applied, but it could not be added to your tracker.",questions:[],answersToSave:i})}return o.status==="blocked"?n({state:"error",stage:null,message:o.message,questions:o.blockers??[],answersToSave:[],diagnostic:o.diagnostic}):o.status==="cancelled"?n({state:"idle",stage:null,message:"Stopped.",questions:[],answersToSave:[]}):n({state:"error",stage:null,message:o.message,questions:[],answersToSave:[],diagnostic:o.diagnostic})}catch(o){return n({state:"error",stage:null,message:o instanceof Error?o.message:"Something went wrong.",questions:[],answersToSave:[]})}}var ke=[];var Ha=["thank you for applying","thanks for applying","application submitted","application was submitted","your application was submitted","application has been submitted","application received","we have received your application","your application has been received","successfully submitted","application sent","your application has been sent","you will get an email confirmation at","return to job search"];function ne(...e){console.info("[banapply]",...e)}var ae=!1,me=!1,Lt=null,G=null;function Wn(e,t){let n=en(document)??{},o=e.extract(document,t),a=s=>n[s]??o[s]??null,r=a("title"),i=a("company");return!r&&!i||r&&(/application (has been|was|is)?\s*submitted/i.test(r)||/thank you for applying/i.test(r)||/your application/i.test(r))?null:{jobUrl:t.href,title:r,company:i,location:a("location"),remote:a("remote"),employmentType:a("employmentType"),externalId:a("externalId"),ats:e.ats,compRaw:a("compRaw"),adapterVersion:e.version}}function qa(e,t){if(!e.expectedExternalId||!e.renderedExternalId)return!1;let n=e.expectedExternalId(t),o=e.renderedExternalId(document);return!n||!o||n===o?!1:(ne("DOM still on",o,"- URL wants",n,"- waiting"),!0)}function Kn(e){if(e.confirmationSelectors.some(o=>document.querySelector(o)))return!0;let t=document.body;if(e.confirmationScope&&(t=e.confirmationScope(),!t))return!1;let n=t?.innerText?.toLowerCase()??"";return Ha.some(o=>n.includes(o))}function Fa(e){return xt(e)?!1:!!(e.querySelector('input[type="file"]')||e.querySelector('input[type="email"]')||e.querySelector('input[name*="resume" i], input[name*="email" i]'))}var Ke=!1;async function Xe(e,t){if(ae&&t)return!0;t&&(Ke=!0);let n=Mt(e),o={type:"CAPTURE",payload:{job:n,applied:t,capturedAt:new Date().toISOString()}},a=await O(o);return a.ok?(t&&(ae=!0,Ke=!1,pe({tone:"success",title:"Application tracked",body:`${a.data.application.title} at ${a.data.application.company.name}`})),!0):(Ke=!1,console.warn("[banapply] capture failed:",a.error,n),pe({tone:"error",title:"BanApply could not save this",body:a.error}),!1)}function jt(e){me||ae||Ke||(me=!0,ne("submit detected, recording:",e.title,"@",e.company),Xe(e,!0))}function $a(e,t){let n=i=>{let s=i.target;if(!(s instanceof HTMLFormElement)||!Fa(s))return;let l=t();l&&jt(l)};document.addEventListener("submit",n,!0);let o,a=()=>{ae||me||o!==void 0||(o=window.setTimeout(()=>{if(o=void 0,ae||me||!Kn(e))return;let i=t();i&&jt(i)},400))},r=new MutationObserver(a);return r.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),()=>{window.clearTimeout(o),document.removeEventListener("submit",n,!0),r.disconnect()}}async function Ja(e){let t=await O({type:"CHECK_DUPLICATE",payload:{jobUrl:e.jobUrl,company:e.company,title:e.title}});return!t.ok||t.data.matches.length===0?null:t.data.matches[0]}function Vn(){if(window.location.hostname.toLowerCase().includes("naukri.com")){let t=document.querySelectorAll('button, a, div[role="button"], [class*="apply"], [class*="comp-site"]');for(let n of t){let o=(n.textContent??"").trim();if(/apply on (company|corporate|employer|external) (site|website)/i.test(o)||/company site/i.test(o)||/company website/i.test(o)||n.matches('[class*="company-site"], [class*="external-apply"], [class*="comp-site"]'))return!0}}return!1}function Ua(){if(Vn())return!1;let e=te??(Qe==="LINKEDIN"?wt:null);return e?e.scope()!==null?!0:Qe==="LINKEDIN"&&Ba():!1}function Ba(){return[...(document.querySelector(".jobs-search__job-details")??document).querySelectorAll("button")].some(t=>/easy apply/i.test(t.getAttribute("aria-label")??t.textContent??""))}function za(e){if(e.state!=="needs-input"){(e.state==="done"||e.state==="running")&&Ee();return}Hn();let t=e.questions.length;pe({tone:"warning",title:t===1?"1 question needs your attention":`${t} questions need your attention`,body:"Complete the required questions in the application form \u2014 jobpilot will automatically resume once filled.",rightPx:qn()?392:16})}function Gn(){let e=te??(Qe==="LINKEDIN"?wt:null);if(!e){Z({state:"error",message:"There is no application form on this page."});return}Ct()||(Z({state:"running",stage:"fill",message:"Starting\u2026",questions:[]}),fe({fresh:!0}).then(t=>{if(!t){Z({state:"error",message:"Could not load your profile."});return}zn({profile:t,flow:e,draftAnswers:!1,readCurrentJob:()=>G,onApplied:n=>Xe(n,!0),onProgress:n=>{Z({state:n.state,stage:n.stage,message:n.message,questions:n.questions,answersToSave:n.answersToSave,answersSaved:!1,diagnostic:n.diagnostic}),za(n)}})}))}var Qe=null,te=null,Nt=!1,ee,Ze=0,Ga=10;async function Ya(){if(ee!==void 0)return ee;let e=Wa();if(!e)return Ze+=1,Ze>=Ga&&(ee=null),null;let t=await fe();return t?(ee=Jt(e,t),ee):null}function Wa(){let e=new URL(window.location.href),t=he(e);return t?Nn(document,t):null}function Ka(){return[...he(new URL(window.location.href))?.descriptionSelectors??[],"main","article",'[class*="description"]'].map(n=>{let o=document.querySelector(n),a=o?.textContent?.trim().length??0;return`${n} ${o?a:"\u2014"}`})}function Va(){let e=he(new URL(window.location.href));if(!e)return!1;for(let t of e.descriptionSelectors??[])if((document.querySelector(t)?.textContent?.trim().length??0)>=50)return!0;return!1}var Xn=null;chrome.storage.onChanged.addListener((e,t)=>{t==="local"&&(e.authToken||e.userEmail)&&G&&et(G,Xn)});async function et(e,t){G=e,Xn=t;let n=await O({type:"GET_SESSION"}),o=n.ok&&n.data.authenticated,a=o?await fe():null;if(o&&!a)return ne("could not load your profile");let r=kn(),i=a&&r?bt(a,r):{fillable:0,total:0},s=Vn();ne("coverage:",r?`${i.fillable} of ${i.total}`:"no application form on this page");let l=t&&!/application (has been|was|is)?\s*submitted/i.test(t.title)&&!/smartapply/i.test(t.companyName)?t:null,u=(c,v)=>({job:e,coverage:i,email:n.ok?n.data.email:null,duplicate:l,authenticated:o,canAutoApply:!s&&te!==null&&(te.open!==void 0||te.scope()!==null),hasForm:r!==null,canApply:Ua(),match:c,isAnalyzingMatch:v,isExternalJob:s,matchDiagnostic:c===null&&o?Ka():void 0}),d={onFill:async c=>{let v=await Zn(c,{silent:!0,root:rt()??void 0});return{filled:v.filled,unanswered:v.unanswered.length}},onSave:()=>Xe(e,!1),onSignOut:()=>{O({type:"LOGOUT"}).then(()=>{Be(),et(e,null)})},onCancelAutoApply:()=>{Nt=!0},onStartSession:()=>Gn(),onContinueSession:()=>Gn(),onCancelSession:()=>Un(),onSaveAnswers:c=>{Z({savingAnswers:!0}),O({type:"SAVE_ANSWERS",payload:{answers:c}}).then(v=>{if(!v.ok){Z({savingAnswers:!1,message:v.error,state:"error"});return}Ve=void 0,Z({savingAnswers:!1,answersSaved:!0})})},onAuth:async(c,v,S)=>{let x=await O({type:c==="login"?"LOGIN":"SIGNUP",payload:{email:v,password:S}});return x.ok&&x.data.authenticated?(et(e,t),null):x.ok?x.data.error??"Could not sign in":x.error},onAutoApply:async(c,v)=>{Nt=!1;let S=te;if(!S){c("There is no application form on this page.","blocked");return}let x=await fe({fresh:!0});if(!x){c("Could not load your profile.","blocked");return}let A=await Re({profile:x,flow:S,draftAnswers:v,job:{title:e.title,company:e.company,jobUrl:e.jobUrl},isCancelled:()=>Nt,onProgress:k=>{let L=k.status==="ready"?"ready":k.status==="blocked"||k.status==="error"?"blocked":"busy";c(k.message,L)}});if(A.blockers?.length){let k=A.blockers.map(L=>L.kind==="invalid"?`\u26A0 ${L.label}`:L.label).join(" \xB7 ");c(`${A.message} ${k}`,"blocked")}A.status==="ready"&&await Xe(e,!1)}},m=ee===void 0;o&&m&&await Tt(u(null,!0),d);let f=o?await Ya():null;o&&m&&await new Promise(c=>setTimeout(c,400)),await Tt(u(f,!1),d)}function Xa(e){let t="",n="",o,a=!1,r=async()=>{if(!a&&!Ct()){a=!0;try{let u=new URL(window.location.href);if(!e.isJobPage(u)){t&&(ne("left the posting"),t="",n="",G=null,Be());return}if(qa(e,u))return;let d=Wn(e,u);if(!d)return;let m=rt(),f=m?m.querySelectorAll("input, select, textarea").length:0,c=[d.externalId,d.title,d.company].join("|"),v=[c,f,Va()?"d":"-"].join("|");if(v===t)return;let S=c!==n;t=v,n=c,G=d,S&&(ae=!1,me=!1,ee=void 0,Ze=0,ne("job:",d.title,"@",d.company));let x=S?await Ja(d):Pt;Pt=x,await et(d,x)}finally{a=!1}}},i=()=>{window.clearTimeout(o),o=window.setTimeout(()=>void r(),300)},s=new MutationObserver(i);s.observe(document.documentElement,{childList:!0,subtree:!0});let l=window.setInterval(()=>void r(),800);return r(),()=>{window.clearTimeout(o),window.clearInterval(l),s.disconnect()}}var Pt=null;async function Qn(){Lt?.(),Lt=null,Ee(),Bn(),On(),ee=void 0,Ze=0,ae=!1,me=!1,G=null,Pt=null;let e=new URL(window.location.href),t=he(e);if(!t)return ne("no adapter for",e.hostname);if(Qe=t.ats,te=Tn(t.ats,t.version),ne("adapter:",t.version,"\xB7 apply flow:",te?.name??"none"),t.isJobPage(e)&&Kn(t)){let a=Wn(t,e);a&&jt(a)}let n=Xa(t),o=$a(t,()=>G);Lt=()=>{n(),o()}}function Qa(){let e=window.location.href,t=()=>{window.location.href!==e&&(e=window.location.href,Qn())};setInterval(t,600);for(let n of["pushState","replaceState"]){let o=history[n];history[n]=function(...a){let r=o.apply(this,a);return queueMicrotask(t),r}}window.addEventListener("popstate",t)}var Ve,We=null;async function fe(e={}){if(!e.fresh&&Ve!==void 0)return Ve;if(!e.fresh&&We)return We;let t=O({type:"GET_PROFILE"}).then(n=>{let o=n.ok?n.data.profile:null;return n.ok&&(Ve=o),o});e.fresh||(We=t);try{return await t}finally{e.fresh||(We=null)}}async function Zn(e,t={}){let n=await fe({fresh:!0});if(!n)return pe({tone:"error",title:"Could not autofill",body:"Sign in from the jobpilot popup, then try again."}),{filled:0,skipped:0,unanswered:[]};let o=je(n,{overwrite:e,root:t.root}),a=await Pe(n,{overwrite:e,root:t.root});o.filled+=a.filled;let r=[`${o.filled} field${o.filled===1?"":"s"} filled`];return o.skipped>0&&r.push(`${o.skipped} already had a value`),t.silent?{filled:o.filled,skipped:o.skipped,unanswered:o.unanswered}:(pe({tone:o.filled>0?"success":"info",title:o.filled>0?"Form filled \u2014 check it before you submit":"Nothing to fill here",body:o.unanswered.length>0?`${r.join(" \xB7 ")}. ${o.unanswered.length} question${o.unanswered.length===1?"":"s"} still need you.`:r.join(" \xB7 "),timeoutMs:8e3}),{filled:o.filled,skipped:o.skipped,unanswered:o.unanswered})}chrome.runtime.onMessage.addListener((e,t,n)=>e?.type==="GET_PAGE_JOB"?(n({ok:!0,data:G}),!1):e?.type==="AUTOFILL_PAGE"?(Zn(e.payload.overwrite).then(o=>n({ok:!0,data:o})),!0):e?.type==="GET_FORM_COVERAGE"?(fe().then(o=>{n({ok:!0,data:o?bt(o):{fillable:0,total:0}})}),!0):!1);function Za(){eo()&&(document.documentElement.dataset.banapplyExtension=chrome.runtime.getManifest().version,document.documentElement.dataset.jobpilotExtension=chrome.runtime.getManifest().version)}function eo(){return/(^|\.)(banapply\.com|jobpilot-3lg\.pages\.dev|pages\.dev|localhost)$/.test(window.location.hostname)}function er(){eo()&&window.addEventListener("message",e=>{if(e.source!==window||e.origin!==window.location.origin)return;let t=e.data;!t||t.source!=="banapply-web"||(t.type==="SESSION"&&typeof t.token=="string"&&t.token?O({type:"ADOPT_SESSION",payload:{token:t.token,email:typeof t.email=="string"?t.email:""}}):t.type==="LOGOUT"&&O({type:"LOGOUT"}))})}var Yn="__banapplyContentScriptRunning";window[Yn]?console.info("[banapply] content script already running here \u2014 second copy stood down"):(window[Yn]=!0,tr());function tr(){Za(),er(),Qa(),Qn().catch(e=>{console.warn("[banapply] init failed:",e)})}})();
//# sourceMappingURL=content.js.map
